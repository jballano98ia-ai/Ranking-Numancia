import { 
  collection, 
  doc, 
  getDocs, 
  getDoc, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  writeBatch, 
  runTransaction,
  Timestamp,
  serverTimestamp
} from 'firebase/firestore';
import { db, auth } from './firebase';
import { Player, Match, Round, PromotionDemotionHistory } from '../types';

// Error Handling Structures required by Firestore Rules/Diagnoser
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Helper to determine points from match sets
export function calculateMatchPoints(score: Match['score'], winnerTeam: 1 | 2) {
  let team1Sets = 0;
  let team2Sets = 0;

  // Set 1
  if (score.set1[0] > score.set1[1]) team1Sets++;
  else if (score.set1[1] > score.set1[0]) team2Sets++;

  // Set 2
  if (score.set2[0] > score.set2[1]) team1Sets++;
  else if (score.set2[1] > score.set2[0]) team2Sets++;

  // Set 3 (optional)
  if (score.set3) {
    if (score.set3[0] > score.set3[1]) team1Sets++;
    else if (score.set3[1] > score.set3[0]) team2Sets++;
  }

  const team1Points = 1 + team1Sets + (winnerTeam === 1 ? 3 : 0);
  const team2Points = 1 + team2Sets + (winnerTeam === 2 ? 3 : 0);

  return {
    team1Points,
    team2Points,
    team1Sets,
    team2Sets
  };
}

// Check if database needs seeding, and seed it if empty
export async function seedDatabase() {
  const playersCol = collection(db, 'players');
  let playersSnapshot;
  
  try {
    playersSnapshot = await getDocs(playersCol);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'players');
  }
  
  if (!playersSnapshot.empty) {
    return; // Already seeded
  }

  console.log('Seeding Padel Ranking Database...');
  const batch = writeBatch(db);

  // Seed standard players across 3 divisions
  const initialPlayers: Omit<Player, 'createdAt'>[] = [
    // Division 1 (Top Level)
    { id: 'p_galan', name: 'Alejandro Galán', email: 'galan@padel.com', division: 'División 1', points: 15, played: 3, won: 3, lost: 0, setsWon: 6, setsLost: 1, gamesWon: 42, gamesLost: 24, role: 'player' },
    { id: 'p_lebron', name: 'Juan Lebrón', email: 'lebron@padel.com', division: 'División 1', points: 11, played: 3, won: 2, lost: 1, setsWon: 5, setsLost: 3, gamesWon: 39, gamesLost: 32, role: 'player' },
    { id: 'p_coello', name: 'Arturo Coello', email: 'coello@padel.com', division: 'División 1', points: 12, played: 3, won: 2, lost: 1, setsWon: 4, setsLost: 2, gamesWon: 34, gamesLost: 28, role: 'player' },
    { id: 'p_tapia', name: 'Agustín Tapia', email: 'tapia@padel.com', division: 'División 1', points: 12, played: 3, won: 2, lost: 1, setsWon: 4, setsLost: 3, gamesWon: 36, gamesLost: 33, role: 'player' },
    { id: 'p_navarro', name: 'Paquito Navarro', email: 'paquito@padel.com', division: 'División 1', points: 4, played: 3, won: 0, lost: 3, setsWon: 1, setsLost: 6, gamesWon: 25, gamesLost: 41, role: 'player' },
    { id: 'p_dinenno', name: 'Martín Di Nenno', email: 'dinenno@padel.com', division: 'División 1', points: 5, played: 3, won: 0, lost: 3, setsWon: 2, setsLost: 6, gamesWon: 28, gamesLost: 46, role: 'player' },

    // Division 2 (Mid Level)
    { id: 'p_bela', name: 'Fernando Belasteguín', email: 'bela@padel.com', division: 'División 2', points: 16, played: 3, won: 3, lost: 0, setsWon: 6, setsLost: 0, gamesWon: 36, gamesLost: 18, role: 'player' },
    { id: 'p_sanyo', name: 'Sanyo Gutiérrez', email: 'sanyo@padel.com', division: 'División 2', points: 12, played: 3, won: 2, lost: 1, setsWon: 4, setsLost: 2, gamesWon: 32, gamesLost: 26, role: 'player' },
    { id: 'p_stupa', name: 'Franco Stupaczuk', email: 'stupa@padel.com', division: 'División 2', points: 10, played: 3, won: 2, lost: 1, setsWon: 4, setsLost: 3, gamesWon: 35, gamesLost: 31, role: 'player' },
    { id: 'p_chingotto', name: 'Federico Chingotto', email: 'chingotto@padel.com', division: 'División 2', points: 7, played: 3, won: 1, lost: 2, setsWon: 3, setsLost: 4, gamesWon: 30, gamesLost: 34, role: 'player' },
    { id: 'p_momo', name: 'Momo González', email: 'momo@padel.com', division: 'División 2', points: 3, played: 3, won: 0, lost: 3, setsWon: 1, setsLost: 6, gamesWon: 22, gamesLost: 40, role: 'player' },
    { id: 'p_ruiz', name: 'Álex Ruiz', email: 'aruiz@padel.com', division: 'División 2', points: 4, played: 3, won: 0, lost: 3, setsWon: 1, setsLost: 6, gamesWon: 24, gamesLost: 44, role: 'player' },

    // Division 3 (Entry Level)
    { id: 'p_yanguas', name: 'Mike Yanguas', email: 'yanguas@padel.com', division: 'División 3', points: 15, played: 3, won: 3, lost: 0, setsWon: 6, setsLost: 1, gamesWon: 40, gamesLost: 22, role: 'player' },
    { id: 'p_garrido', name: 'Javi Garrido', email: 'garrido@padel.com', division: 'División 3', points: 12, played: 3, won: 2, lost: 1, setsWon: 4, setsLost: 2, gamesWon: 32, gamesLost: 25, role: 'player' },
    { id: 'p_nieto', name: 'Coki Nieto', email: 'nieto@padel.com', division: 'División 3', points: 11, played: 3, won: 2, lost: 1, setsWon: 5, setsLost: 3, gamesWon: 41, gamesLost: 34, role: 'player' },
    { id: 'p_sanz', name: 'Jon Sanz', email: 'sanz@padel.com', division: 'División 3', points: 6, played: 3, won: 1, lost: 2, setsWon: 2, setsLost: 4, gamesWon: 24, gamesLost: 32, role: 'player' },
    { id: 'p_rubio', name: 'Gonzalo Rubio', email: 'rubio@padel.com', division: 'División 3', points: 4, played: 3, won: 0, lost: 3, setsWon: 1, setsLost: 6, gamesWon: 26, gamesLost: 42, role: 'player' },
    { id: 'p_jruiz', name: 'Javi Ruiz', email: 'jruiz@padel.com', division: 'División 3', points: 3, played: 3, won: 0, lost: 3, setsWon: 0, setsLost: 6, gamesWon: 18, gamesLost: 36, role: 'player' },

    // Admin User account
    { id: 'p_admin', name: 'Administrador Club', email: 'admin@padel.com', division: 'División 1', points: 0, played: 0, won: 0, lost: 0, setsWon: 0, setsLost: 0, gamesWon: 0, gamesLost: 0, role: 'admin' }
  ];

  initialPlayers.forEach(p => {
    const docRef = doc(db, 'players', p.id);
    batch.set(docRef, {
      ...p,
      createdAt: serverTimestamp()
    });
  });

  // Seed the first active Round (Jornada 1)
  const firstRound: Round = {
    id: 'round_1',
    number: 1,
    startDate: Date.now() - (4 * 24 * 60 * 60 * 1000), // Started 4 days ago
    endDate: Date.now() + (3 * 24 * 60 * 60 * 1000),   // Ends in 3 days
    status: 'active'
  };

  const roundRef = doc(db, 'rounds', firstRound.id);
  batch.set(roundRef, firstRound);

  // Add some initial completed matches to make it look realistic
  const sampleMatches: Match[] = [
    // Division 1
    {
      id: 'm_1',
      type: 'doubles',
      division: 'División 1',
      playerIds: ['p_galan', 'p_lebron', 'p_coello', 'p_tapia'],
      playerNames: {
        'p_galan': 'Alejandro Galán',
        'p_lebron': 'Juan Lebrón',
        'p_coello': 'Arturo Coello',
        'p_tapia': 'Agustín Tapia'
      },
      team1: ['p_galan', 'p_lebron'],
      team2: ['p_coello', 'p_tapia'],
      score: {
        set1: [6, 4],
        set2: [3, 6],
        set3: [7, 5]
      },
      winnerTeam: 1,
      pointsAwarded: {
        'p_galan': 6, // 1 part + 2 sets + 3 win = 6
        'p_lebron': 6,
        'p_coello': 2, // 1 part + 1 set = 2
        'p_tapia': 2
      },
      date: Date.now() - (3 * 24 * 60 * 60 * 1000),
      roundId: 'round_1'
    },
    // Division 2
    {
      id: 'm_2',
      type: 'doubles',
      division: 'División 2',
      playerIds: ['p_bela', 'p_sanyo', 'p_stupa', 'p_chingotto'],
      playerNames: {
        'p_bela': 'Fernando Belasteguín',
        'p_sanyo': 'Sanyo Gutiérrez',
        'p_stupa': 'Franco Stupaczuk',
        'p_chingotto': 'Federico Chingotto'
      },
      team1: ['p_bela', 'p_sanyo'],
      team2: ['p_stupa', 'p_chingotto'],
      score: {
        set1: [6, 2],
        set2: [6, 3]
      },
      winnerTeam: 1,
      pointsAwarded: {
        'p_bela': 6, // 1 part + 2 sets + 3 win = 6
        'p_sanyo': 6,
        'p_stupa': 1, // 1 part + 0 sets = 1
        'p_chingotto': 1
      },
      date: Date.now() - (2 * 24 * 60 * 60 * 1000),
      roundId: 'round_1'
    },
    // Division 3
    {
      id: 'm_3',
      type: 'singles',
      division: 'División 3',
      playerIds: ['p_yanguas', 'p_garrido'],
      playerNames: {
        'p_yanguas': 'Mike Yanguas',
        'p_garrido': 'Javi Garrido'
      },
      team1: ['p_yanguas'],
      team2: ['p_garrido'],
      score: {
        set1: [6, 3],
        set2: [7, 6]
      },
      winnerTeam: 1,
      pointsAwarded: {
        'p_yanguas': 6,
        'p_garrido': 1
      },
      date: Date.now() - (1 * 24 * 60 * 60 * 1000),
      roundId: 'round_1'
    }
  ];

  sampleMatches.forEach(m => {
    const matchRef = doc(db, 'matches', m.id);
    batch.set(matchRef, m);
  });

  try {
    await batch.commit();
    console.log('Database seeded successfully.');
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'batch_commit');
  }
}

// Get all players
export async function getPlayers(): Promise<Player[]> {
  const playersCol = collection(db, 'players');
  const q = query(playersCol, orderBy('points', 'desc'), orderBy('won', 'desc'));
  
  try {
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Player));
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'players');
  }
}

// Get active round
export async function getActiveRound(): Promise<Round> {
  const roundsCol = collection(db, 'rounds');
  const q = query(roundsCol, where('status', '==', 'active'));
  let snapshot;
  
  try {
    snapshot = await getDocs(q);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'rounds');
  }
  
  if (snapshot.empty) {
    // Fallback: create a new active round if none found
    const newRound: Round = {
      id: `round_${Date.now()}`,
      number: 1,
      startDate: Date.now(),
      endDate: Date.now() + (7 * 24 * 60 * 60 * 1000),
      status: 'active'
    };
    try {
      await setDoc(doc(db, 'rounds', newRound.id), newRound);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `rounds/${newRound.id}`);
    }
    return newRound;
  }
  
  const activeDoc = snapshot.docs[0];
  return { id: activeDoc.id, ...activeDoc.data() } as Round;
}

// Get all matches for a specific round, or all matches
export async function getMatches(roundId?: string): Promise<Match[]> {
  const matchesCol = collection(db, 'matches');
  let q = query(matchesCol, orderBy('date', 'desc'));
  if (roundId) {
    q = query(matchesCol, where('roundId', '==', roundId), orderBy('date', 'desc'));
  }
  try {
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Match));
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'matches');
  }
}

// Get all completed rounds
export async function getRounds(): Promise<Round[]> {
  const roundsCol = collection(db, 'rounds');
  const q = query(roundsCol, orderBy('number', 'desc'));
  try {
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Round));
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'rounds');
  }
}

// Register a new player
export async function registerPlayerProfile(id: string, name: string, email: string, role: 'admin' | 'player' = 'player'): Promise<Player> {
  const playerRef = doc(db, 'players', id);
  let playerSnap;
  try {
    playerSnap = await getDoc(playerRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, `players/${id}`);
  }

  if (playerSnap.exists()) {
    return playerSnap.data() as Player;
  }

  // New players start in Division 3 with 0 points
  const newPlayer: Player = {
    id,
    name,
    email: email.toLowerCase().trim(),
    division: 'División 3',
    points: 0,
    played: 0,
    won: 0,
    lost: 0,
    setsWon: 0,
    setsLost: 0,
    gamesWon: 0,
    gamesLost: 0,
    role,
    partnerId: null
  };

  try {
    await setDoc(playerRef, {
      ...newPlayer,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `players/${id}`);
  }

  return newPlayer;
}

// Set or clear player's partner with mutual binding
export async function updatePlayerPartner(playerId: string, partnerId: string | null): Promise<void> {
  const batch = writeBatch(db);
  
  // 1. Get current player data to see if they already have a partner that we should clear
  const playerRef = doc(db, 'players', playerId);
  const playerSnap = await getDoc(playerRef);
  
  if (playerSnap.exists()) {
    const playerData = playerSnap.data() as Player;
    const oldPartnerId = playerData.partnerId;
    
    // Clear old partner's link if exists
    if (oldPartnerId) {
      const oldPartnerRef = doc(db, 'players', oldPartnerId);
      batch.update(oldPartnerRef, { partnerId: null });
    }
  }

  // 2. If we are setting a new partner
  if (partnerId) {
    const partnerRef = doc(db, 'players', partnerId);
    const partnerSnap = await getDoc(partnerRef);
    
    if (partnerSnap.exists()) {
      const partnerData = partnerSnap.data() as Player;
      const oldPartnerOfNewPartner = partnerData.partnerId;
      
      // Clear old partner's old partner link
      if (oldPartnerOfNewPartner) {
        const oldPartnerOfNewPartnerRef = doc(db, 'players', oldPartnerOfNewPartner);
        batch.update(oldPartnerOfNewPartnerRef, { partnerId: null });
      }
    }
    
    // Set mutual links
    batch.update(playerRef, { partnerId: partnerId });
    batch.update(partnerRef, { partnerId: playerId });
  } else {
    // Just clear current player's link
    batch.update(playerRef, { partnerId: null });
  }

  try {
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `update_partner_${playerId}`);
  }
}

// Find a player by email (useful for simulation fallback)
export async function getPlayerByEmail(email: string): Promise<Player | null> {
  const playersCol = collection(db, 'players');
  const q = query(playersCol, where('email', '==', email.toLowerCase().trim()));
  try {
    const snapshot = await getDocs(q);
    if (snapshot.empty) return null;
    const playerDoc = snapshot.docs[0];
    return { id: playerDoc.id, ...playerDoc.data() } as Player;
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, 'players');
  }
}

// Post a new match and update player stats atomically
export async function addMatch(matchData: Omit<Match, 'id' | 'pointsAwarded'>): Promise<string> {
  const matchId = `match_${Date.now()}`;
  
  // Calculate points
  const points = calculateMatchPoints(matchData.score, matchData.winnerTeam);
  
  const pointsAwarded: { [id: string]: number } = {};
  
  // Distribute points to Team 1 players
  matchData.team1.forEach(id => {
    pointsAwarded[id] = points.team1Points;
  });
  
  // Distribute points to Team 2 players
  matchData.team2.forEach(id => {
    pointsAwarded[id] = points.team2Points;
  });

  const fullMatch: Match = {
    id: matchId,
    ...matchData,
    pointsAwarded
  };

  // Run transaction to ensure atomicity
  try {
    await runTransaction(db, async (transaction) => {
      // 1. Save match
      const matchRef = doc(db, 'matches', matchId);
      transaction.set(matchRef, fullMatch);

      // Calculate details for stats updates
      const t1Won = matchData.winnerTeam === 1;
      const t2Won = matchData.winnerTeam === 2;

      const t1SetsWon = points.team1Sets;
      const t1SetsLost = points.team2Sets;
      const t2SetsWon = points.team2Sets;
      const t2SetsLost = points.team1Sets;

      // Games calculations
      let t1Games = 0;
      let t2Games = 0;

      t1Games += matchData.score.set1[0];
      t2Games += matchData.score.set1[1];
      t1Games += matchData.score.set2[0];
      t2Games += matchData.score.set2[1];
      if (matchData.score.set3) {
        t1Games += matchData.score.set3[0];
        t2Games += matchData.score.set3[1];
      }

      // 2. Update players
      const allParticipants = [...matchData.team1, ...matchData.team2];
      
      for (const pId of allParticipants) {
        const pRef = doc(db, 'players', pId);
        const pSnap = await transaction.get(pRef);
        
        if (pSnap.exists()) {
          const pData = pSnap.data() as Player;
          const isT1 = matchData.team1.includes(pId);
          
          const pts = pointsAwarded[pId];
          const isWinner = isT1 ? t1Won : t2Won;
          
          transaction.update(pRef, {
            points: (pData.points || 0) + pts,
            played: (pData.played || 0) + 1,
            won: (pData.won || 0) + (isWinner ? 1 : 0),
            lost: (pData.lost || 0) + (isWinner ? 0 : 1),
            setsWon: (pData.setsWon || 0) + (isT1 ? t1SetsWon : t2SetsWon),
            setsLost: (pData.setsLost || 0) + (isT1 ? t1SetsLost : t2SetsLost),
            gamesWon: (pData.gamesWon || 0) + (isT1 ? t1Games : t2Games),
            gamesLost: (pData.gamesLost || 0) + (isT1 ? t2Games : t1Games)
          });
        }
      }
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `matches/${matchId}`);
  }

  return matchId;
}

// Custom sort function for ranking leaderboard
export function sortPlayersForRanking(players: Player[]): Player[] {
  return [...players].sort((a, b) => {
    // 1. Points
    if (b.points !== a.points) return b.points - a.points;
    // 2. Matches won
    if (b.won !== a.won) return b.won - a.won;
    // 3. Set difference
    const diffA_sets = (a.setsWon - a.setsLost);
    const diffB_sets = (b.setsWon - b.setsLost);
    if (diffB_sets !== diffA_sets) return diffB_sets - diffA_sets;
    // 4. Game difference
    const diffA_games = (a.gamesWon - a.gamesLost);
    const diffB_games = (b.gamesWon - b.gamesLost);
    return diffB_games - diffA_games;
  });
}

// Close current round and perform automatic promotions/demotions
export async function closeCurrentRound(roundId: string, durationDays: number = 7): Promise<string> {
  const nextRoundId = `round_${Date.now()}`;
  
  try {
    await runTransaction(db, async (transaction) => {
      const roundRef = doc(db, 'rounds', roundId);
      const roundSnap = await transaction.get(roundRef);
      
      if (!roundSnap.exists() || roundSnap.data().status === 'completed') {
        throw new Error('Jornada no encontrada o ya cerrada');
      }

      const currentRoundData = roundSnap.data() as Round;

      // Get all players
      const playersCol = collection(db, 'players');
      const playersSnapshot = await getDocs(playersCol);
      const allPlayers = playersSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Player));

      // Sort players by division and ranking
      const div1Players = sortPlayersForRanking(allPlayers.filter(p => p.division === 'División 1' && p.role !== 'admin'));
      const div2Players = sortPlayersForRanking(allPlayers.filter(p => p.division === 'División 2' && p.role !== 'admin'));
      const div3Players = sortPlayersForRanking(allPlayers.filter(p => p.division === 'División 3' && p.role !== 'admin'));

      const history: PromotionDemotionHistory[] = [];

      // Apply Division 1 Demotions (if we have players)
      const demotingFromDiv1 = div1Players.slice(-2);
      // Apply Division 2 Promotions & Demotions
      const promotingFromDiv2 = div2Players.slice(0, 2);
      const demotingFromDiv2 = div2Players.slice(-2);
      // Apply Division 3 Promotions
      const promotingFromDiv3 = div3Players.slice(0, 2);

      // Create a mapping of new divisions
      const playerNewDivision: { [id: string]: string } = {};

      // Standard default
      allPlayers.forEach(p => {
        playerNewDivision[p.id] = p.division;
      });

      // Update with promotions / demotions
      demotingFromDiv1.forEach(p => {
        if (div1Players.length > 2) { // Ensure we don't demote if division is too empty
          playerNewDivision[p.id] = 'División 2';
          history.push({
            playerId: p.id,
            playerName: p.name,
            fromDivision: 'División 1',
            toDivision: 'División 2',
            type: 'demoted',
            points: p.points
          });
        }
      });

      promotingFromDiv2.forEach(p => {
        playerNewDivision[p.id] = 'División 1';
        history.push({
          playerId: p.id,
          playerName: p.name,
          fromDivision: 'División 2',
          toDivision: 'División 1',
          type: 'promoted',
          points: p.points
        });
      });

      demotingFromDiv2.forEach(p => {
        if (div2Players.length > 2) {
          playerNewDivision[p.id] = 'División 3';
          history.push({
            playerId: p.id,
            playerName: p.name,
            fromDivision: 'División 2',
            toDivision: 'División 3',
            type: 'demoted',
            points: p.points
          });
        }
      });

      promotingFromDiv3.forEach(p => {
        playerNewDivision[p.id] = 'División 2';
        history.push({
          playerId: p.id,
          playerName: p.name,
          fromDivision: 'División 3',
          toDivision: 'División 2',
          type: 'promoted',
          points: p.points
        });
      });

      // For all other players, record that they stayed
      allPlayers.forEach(p => {
        if (p.role === 'admin') return;
        
        const moved = history.some(h => h.playerId === p.id);
        if (!moved) {
          history.push({
            playerId: p.id,
            playerName: p.name,
            fromDivision: p.division,
            toDivision: p.division,
            type: 'stayed',
            points: p.points
          });
        }
      });

      // Write player updates: Set new division and RESET current round stats
      allPlayers.forEach(p => {
        if (p.role === 'admin') return;
        
        const pRef = doc(db, 'players', p.id);
        transaction.update(pRef, {
          division: playerNewDivision[p.id],
          points: 0,
          played: 0,
          won: 0,
          lost: 0,
          setsWon: 0,
          setsLost: 0,
          gamesWon: 0,
          gamesLost: 0
        });
      });

      // Mark current round as completed with history
      transaction.update(roundRef, {
        status: 'completed',
        endDate: Date.now(),
        promotionsDemotions: history
      });

      // Create new round
      const nextRound: Round = {
        id: nextRoundId,
        number: currentRoundData.number + 1,
        startDate: Date.now(),
        endDate: Date.now() + (durationDays * 24 * 60 * 60 * 1000),
        status: 'active'
      };
      
      const nextRoundRef = doc(db, 'rounds', nextRoundId);
      transaction.set(nextRoundRef, nextRound);
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `rounds/${roundId}`);
  }

  return nextRoundId;
}
