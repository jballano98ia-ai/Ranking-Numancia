import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyA1Q9hEBECX5xPHQAVVhEFCZBK5Y-v22VY",
  authDomain: "boxwood-moon-92t1j.firebaseapp.com",
  projectId: "boxwood-moon-92t1j",
  storageBucket: "boxwood-moon-92t1j.firebasestorage.app",
  messagingSenderId: "18062415054",
  appId: "1:18062415054:web:e0c9aa6250a6d3a88b6c9f"
};

const app = initializeApp(firebaseConfig);

// Initialize Firestore with the specific database ID from config
export const db = getFirestore(app, "ai-studio-4c6c29f0-cc23-4634-9016-34363c7aac30");
export const auth = getAuth(app);
