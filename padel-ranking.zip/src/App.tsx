import React, { useState, useEffect } from 'react';
import { Player } from './types';
import { seedDatabase, getPlayers, handleFirestoreError, OperationType } from './lib/db';
import { auth, db } from './lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';

// Component Imports
import Login from './components/Login';
import Navigation from './components/Navigation';
import HomeView from './components/HomeView';
import MatchesView from './components/MatchesView';
import RankingView from './components/RankingView';
import RulesView from './components/RulesView';
import AdminView from './components/AdminView';

// Styling and Icon imports
import { Wifi, Battery, Trophy, Smartphone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [currentPlayer, setCurrentPlayer] = useState<Player | null>(null);
  const [activeTab, setActiveTab] = useState<string>('home');
  const [dbSeeded, setDbSeeded] = useState(false);
  const [loading, setLoading] = useState(true);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Initialize and Seed Database on Mount
  useEffect(() => {
    async function initDb() {
      try {
        await seedDatabase();
        setDbSeeded(true);
      } catch (err) {
        console.error('Error during database initialization/seeding:', err);
      } finally {
        setLoading(false);
      }
    }
    initDb();
  }, []);

  // Sync auth state with Firestore players profile
  useEffect(() => {
    if (!dbSeeded) return;

    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          let playerSnap;
          try {
            playerSnap = await getDoc(doc(db, 'players', firebaseUser.uid));
          } catch (error) {
            handleFirestoreError(error, OperationType.GET, `players/${firebaseUser.uid}`);
          }
          if (playerSnap.exists()) {
            setCurrentPlayer(playerSnap.data() as Player);
          } else {
            // Profile doesn't exist yet, we will rely on Login.tsx registration to set it
          }
        } catch (err) {
          console.error('Error syncing user profile:', err);
        }
      } else {
        // No firebase user, check if we have a locally simulated player session in localStorage
        const cachedSimId = localStorage.getItem('sim_player_id');
        if (cachedSimId) {
          try {
            let playerSnap;
            try {
              playerSnap = await getDoc(doc(db, 'players', cachedSimId));
            } catch (error) {
              handleFirestoreError(error, OperationType.GET, `players/${cachedSimId}`);
            }
            if (playerSnap.exists()) {
              setCurrentPlayer(playerSnap.data() as Player);
            } else {
              localStorage.removeItem('sim_player_id');
            }
          } catch (err) {
            console.error('Error syncing simulated profile:', err);
            localStorage.removeItem('sim_player_id');
          }
        }
      }
    });

    return () => unsubscribe();
  }, [dbSeeded, refreshTrigger]);

  const handleLoginSuccess = (player: Player) => {
    // If it's a simulated player account, store its ID in localStorage for persistence
    if (player.id.startsWith('p_')) {
      localStorage.setItem('sim_player_id', player.id);
    }
    setCurrentPlayer(player);
    setActiveTab('home');
  };

  const handleLogout = async () => {
    try {
      localStorage.removeItem('sim_player_id');
      await signOut(auth);
      setCurrentPlayer(null);
      setActiveTab('home');
    } catch (err) {
      console.error('Error signing out:', err);
    }
  };

  // Re-fetch latest logged-in player details when matches are recorded or rounds closed
  const triggerRefresh = async () => {
    setRefreshTrigger(prev => prev + 1);
    if (currentPlayer) {
      try {
        let playerSnap;
        try {
          playerSnap = await getDoc(doc(db, 'players', currentPlayer.id));
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `players/${currentPlayer.id}`);
        }
        if (playerSnap.exists()) {
          setCurrentPlayer(playerSnap.data() as Player);
        }
      } catch (err) {
        console.error('Error refreshing current player:', err);
      }
    }
  };

  // View Router
  const renderActiveView = () => {
    if (!currentPlayer) return null;

    switch (activeTab) {
      case 'home':
        return (
          <HomeView 
            currentPlayer={currentPlayer} 
            onMatchSubmitted={triggerRefresh} 
          />
        );
      case 'matches':
        return (
          <MatchesView 
            currentPlayer={currentPlayer} 
            refreshTrigger={refreshTrigger} 
          />
        );
      case 'ranking':
        return (
          <RankingView 
            currentPlayer={currentPlayer} 
            refreshTrigger={refreshTrigger} 
          />
        );
      case 'rules':
        return <RulesView />;
      case 'admin':
        return (
          <AdminView 
            currentPlayer={currentPlayer} 
            onAdminActionCompleted={triggerRefresh} 
          />
        );
      default:
        return <HomeView currentPlayer={currentPlayer} onMatchSubmitted={triggerRefresh} />;
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen bg-[#0F172A] text-slate-100 space-y-4">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#BEF264]/10 text-[#BEF264] border border-[#BEF264]/20 mb-2 animate-pulse">
          <Trophy className="w-8 h-8" />
        </div>
        <h2 className="text-sm font-bold tracking-widest font-mono uppercase text-slate-300">Cargando Liga de Pádel...</h2>
        <div className="w-48 bg-[#1E293B] h-1.5 rounded-full overflow-hidden border border-slate-700/50">
          <div className="bg-[#BEF264] h-full animate-infinite-loading w-1/3 rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div id="app_root_wrapper" className="min-h-screen bg-[#0F172A] flex items-center justify-center font-sans">
      
      {/* 
        Sleek Android Smartphone Frame
        Centered on large screens, standard full-screen on true mobile devices.
      */}
      <div className="w-full max-w-md min-h-screen md:min-h-[85vh] md:max-h-[90vh] md:rounded-3xl bg-[#0F172A] md:border md:border-slate-700/50 shadow-2xl relative overflow-y-auto flex flex-col scrollbar-none md:my-4">
        
        {/* Android Status Bar Emulator */}
        <div className="sticky top-0 bg-[#0F172A] z-50 px-4 py-2 flex justify-between items-center text-slate-400 text-[10px] font-mono border-b border-slate-700/30">
          <span>10:42 AM</span>
          <div className="flex items-center gap-1.5">
            <Wifi className="w-3.5 h-3.5 text-slate-400" />
            <span className="font-semibold text-[9px] tracking-wider">5G</span>
            <Battery className="w-4 h-4 text-slate-400" />
          </div>
        </div>

        {/* Dynamic App Header */}
        <header className="sticky top-[26px] bg-[#1E293B]/90 backdrop-blur-md z-45 px-5 py-3 border-b border-slate-700/50 flex justify-between items-center">
          <h1 className="text-base font-extrabold tracking-tight text-white flex items-center gap-1.5 font-sans">
            <Smartphone className="w-4 h-4 text-[#BEF264]" />
            PÁDEL <span className="text-[#BEF264]">RANKING</span>
          </h1>
          {currentPlayer && (
            <span className="text-[10px] bg-[#0F172A] text-slate-400 font-bold px-2 py-0.5 rounded border border-slate-700/50">
              {currentPlayer.role === 'admin' ? 'CLUB ADMIN' : 'JUGADOR'}
            </span>
          )}
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto pb-16">
          <AnimatePresence mode="wait">
            {!currentPlayer ? (
              <motion.div
                key="login_screen"
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.15 }}
                className="min-h-full"
              >
                <Login onLoginSuccess={handleLoginSuccess} />
              </motion.div>
            ) : (
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -5 }}
                transition={{ duration: 0.15 }}
                className="min-h-full"
              >
                {renderActiveView()}
              </motion.div>
            )}
          </AnimatePresence>
        </main>

        {/* Bottom Tab Navigation Bar */}
        {currentPlayer && (
          <Navigation 
            activeTab={activeTab} 
            setActiveTab={setActiveTab} 
            isAdmin={currentPlayer.role === 'admin'}
            onLogout={handleLogout}
          />
        )}

      </div>
    </div>
  );
}
