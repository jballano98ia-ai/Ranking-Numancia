import React, { useState, useEffect } from 'react';
import { Player, Match, Round } from '../types';
import { getPlayers, addMatch, getActiveRound, updatePlayerPartner } from '../lib/db';
import { 
  Trophy, 
  Calendar, 
  PlusCircle, 
  User as UserIcon, 
  ChevronRight, 
  Info, 
  CheckCircle, 
  ShieldAlert,
  Hash
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface HomeViewProps {
  currentPlayer: Player;
  onMatchSubmitted: () => void;
}

export default function HomeView({ currentPlayer, onMatchSubmitted }: HomeViewProps) {
  const [activeRound, setActiveRound] = useState<Round | null>(null);
  const [playersList, setPlayersList] = useState<Player[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [isSelectingPartner, setIsSelectingPartner] = useState(false);
  const [homePartnerId, setHomePartnerId] = useState('');

  // Form State
  const [matchType, setMatchType] = useState<'singles' | 'doubles'>('doubles');
  
  // Team 1 players: By default, the current user is Player 1 in Team 1
  const [partnerId, setPartnerId] = useState('');
  const [opp1Id, setOpp1Id] = useState('');
  const [opp2Id, setOpp2Id] = useState('');
  
  // Score State (games per set)
  const [set1T1, setSet1T1] = useState<number>(0);
  const [set1T2, setSet1T2] = useState<number>(0);
  const [set2T1, setSet2T1] = useState<number>(0);
  const [set2T2, setSet2T2] = useState<number>(0);
  const [set3T1, setSet3T1] = useState<number>(0);
  const [set3T2, setSet3T2] = useState<number>(0);

  // Load active round and potential partners/opponents
  useEffect(() => {
    async function loadData() {
      try {
        const round = await getActiveRound();
        setActiveRound(round);
        
        const allPlayers = await getPlayers();
        setPlayersList(allPlayers);
      } catch (err) {
        console.error('Error loading home view data:', err);
      }
    }
    loadData();
  }, [currentPlayer]);

  // Filter players list for selection (usually only show players of the current player's division)
  const divisionPlayers = playersList.filter(
    p => p.id !== currentPlayer.id && p.division === currentPlayer.division && p.role !== 'admin'
  );

  // If there are not enough players in the division, fallback to showing all players except current
  const availablePlayersForSelect = divisionPlayers.length > 0 
    ? divisionPlayers 
    : playersList.filter(p => p.id !== currentPlayer.id && p.role !== 'admin');

  // Determine if a 3rd set is required
  // Set 1 Winner
  const set1Winner = set1T1 > set1T2 ? 1 : set1T2 > set1T1 ? 2 : null;
  // Set 2 Winner
  const set2Winner = set2T1 > set2T2 ? 1 : set2T2 > set2T1 ? 2 : null;
  
  const isSet3Required = set1Winner !== null && set2Winner !== null && set1Winner !== set2Winner;

  const handleRecordMatch = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');
    setLoading(true);

    if (!activeRound) {
      setErrorMsg('No hay ninguna jornada activa.');
      setLoading(false);
      return;
    }

    try {
      // Validate players
      if (matchType === 'doubles') {
        if (!partnerId || !opp1Id || !opp2Id) {
          throw new Error('Por favor, selecciona a todos los integrantes de la partida doble.');
        }
        const uniqueIds = new Set([currentPlayer.id, partnerId, opp1Id, opp2Id]);
        if (uniqueIds.size !== 4) {
          throw new Error('Un jugador no puede estar duplicado en el partido.');
        }
      } else {
        if (!opp1Id) {
          throw new Error('Por favor, selecciona a tu oponente.');
        }
        if (opp1Id === currentPlayer.id) {
          throw new Error('No puedes jugar contra ti mismo.');
        }
      }

      // Validate scores
      if (set1T1 === set1T2 || set2T1 === set2T2) {
        throw new Error('Los sets no pueden terminar en empate.');
      }
      if (isSet3Required && set3T1 === set3T2) {
        throw new Error('El tercer set de desempate no puede terminar en empate.');
      }

      // Check games are reasonable (at least 6 games to win a set unless a tiebreak, standard padel set is usually first to 6 or 7)
      const validateSetScore = (t1: number, t2: number, setName: string) => {
        if (t1 < 0 || t2 < 0) throw new Error(`Puntuaciones inválidas en ${setName}`);
        if (t1 > 7 || t2 > 7) throw new Error(`La puntuación de ${setName} parece demasiado alta (máximo 7).`);
        // Standard set check
        const max = Math.max(t1, t2);
        const min = Math.min(t1, t2);
        if (max < 6) {
          throw new Error(`En el ${setName}, el ganador debe llegar al menos a 6 juegos.`);
        }
        if (max === 6 && min > 4) {
          throw new Error(`En el ${setName}, para ganar 6 debe haber diferencia de 2 juegos (6-4). Si llegó a 5, debe ser 7-5 o 7-6.`);
        }
        if (max === 7 && min !== 5 && min !== 6) {
          throw new Error(`En el ${setName}, el resultado 7 debe ser 7-5 o 7-6.`);
        }
      };

      validateSetScore(set1T1, set1T2, 'primer set');
      validateSetScore(set2T1, set2T2, 'segundo set');
      if (isSet3Required) {
        validateSetScore(set3T1, set3T2, 'tercer set');
      }

      // Determine match winner
      let t1Sets = 0;
      let t2Sets = 0;
      if (set1T1 > set1T2) t1Sets++; else t2Sets++;
      if (set2T1 > set2T2) t1Sets++; else t2Sets++;
      if (isSet3Required) {
        if (set3T1 > set3T2) t1Sets++; else t2Sets++;
      }

      const winnerTeam = t1Sets > t2Sets ? 1 : 2;

      // Prepare players & names map
      const team1 = matchType === 'doubles' ? [currentPlayer.id, partnerId] : [currentPlayer.id];
      const team2 = matchType === 'doubles' ? [opp1Id, opp2Id] : [opp1Id];

      const playerIds = [...team1, ...team2];
      const playerNames: { [id: string]: string } = {};

      playerIds.forEach(id => {
        if (id === currentPlayer.id) {
          playerNames[id] = currentPlayer.name;
        } else {
          const found = playersList.find(p => p.id === id);
          playerNames[id] = found ? found.name : 'Jugador';
        }
      });

      const score: Match['score'] = {
        set1: [set1T1, set1T2],
        set2: [set2T1, set2T2],
        ...(isSet3Required ? { set3: [set3T1, set3T2] } : {})
      };

      // Save match to Firestore
      await addMatch({
        type: matchType,
        division: currentPlayer.division,
        playerIds,
        playerNames,
        team1,
        team2,
        score,
        winnerTeam,
        date: Date.now(),
        roundId: activeRound.id
      });

      setSuccessMsg('¡Partido registrado con éxito! Los puntos han sido calculados y asignados.');
      setIsRecording(false);
      onMatchSubmitted();
      
      // Reset form fields
      setPartnerId('');
      setOpp1Id('');
      setOpp2Id('');
      setSet1T1(0); setSet1T2(0);
      setSet2T1(0); setSet2T2(0);
      setSet3T1(0); setSet3T2(0);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error al registrar el partido.');
    } finally {
      setLoading(false);
    }
  };

  // Format date readable
  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('es-ES', {
      day: 'numeric',
      month: 'short'
    });
  };

  // Calculate days left in Round
  const getDaysLeftString = () => {
    if (!activeRound) return '';
    const diff = activeRound.endDate - Date.now();
    if (diff <= 0) return 'Jornada finalizada (pendiente de cierre)';
    
    const days = Math.floor(diff / (24 * 60 * 60 * 1000));
    const hours = Math.floor((diff % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));
    
    if (days === 0) {
      return `Quedan ${hours} horas`;
    }
    return `Quedan ${days} días y ${hours}h`;
  };

  const getRoundProgressPercent = () => {
    if (!activeRound) return 0;
    const total = activeRound.endDate - activeRound.startDate;
    const passed = Date.now() - activeRound.startDate;
    const percent = Math.min(100, Math.max(0, (passed / total) * 100));
    return percent;
  };

  return (
    <div id="home_view_container" className="space-y-6 pb-24 text-white p-4">
      
      {/* Welcome & Profile Header */}
      <motion.div 
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative bg-[#1E293B] border border-slate-700/50 rounded-3xl p-5 overflow-hidden shadow-xl"
      >
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#BEF264]/5 rounded-full blur-2xl"></div>
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-[#BEF264] text-slate-900 flex items-center justify-center font-bold text-xl uppercase tracking-tight shadow-md border-2 border-[#BEF264]">
            {currentPlayer.name.charAt(0)}
          </div>
          <div className="space-y-1">
            <span className="text-xs font-semibold text-[#BEF264] uppercase tracking-widest">{currentPlayer.division}</span>
            <h2 className="text-xl font-bold tracking-tight text-white leading-tight">Hola, {currentPlayer.name}</h2>
            <p className="text-xs text-slate-400 flex items-center gap-1 font-mono">
              <UserIcon className="w-3 h-3" />
              {currentPlayer.email}
            </p>
          </div>
        </div>

        {/* Player mini-stats grid */}
        <div className="grid grid-cols-4 gap-2 mt-5 border-t border-slate-700/30 pt-4 text-center">
          <div className="bg-[#0F172A]/40 p-2 rounded-xl border border-slate-700/30">
            <div className="text-[10px] uppercase font-semibold text-slate-500">Puntos</div>
            <div className="text-base font-extrabold text-[#BEF264] mt-0.5">{currentPlayer.points || 0}</div>
          </div>
          <div className="bg-[#0F172A]/40 p-2 rounded-xl border border-slate-700/30">
            <div className="text-[10px] uppercase font-semibold text-slate-500">Jugados</div>
            <div className="text-base font-extrabold text-white mt-0.5">{currentPlayer.played || 0}</div>
          </div>
          <div className="bg-[#0F172A]/40 p-2 rounded-xl border border-slate-700/30">
            <div className="text-[10px] uppercase font-semibold text-slate-500">Ganados</div>
            <div className="text-base font-extrabold text-emerald-400 mt-0.5">{currentPlayer.won || 0}</div>
          </div>
          <div className="bg-[#0F172A]/40 p-2 rounded-xl border border-slate-700/30">
            <div className="text-[10px] uppercase font-semibold text-slate-500">Perdidos</div>
            <div className="text-base font-extrabold text-rose-400 mt-0.5">{currentPlayer.lost || 0}</div>
          </div>
        </div>
      </motion.div>

      {/* Dynamic Partner Selector Box */}
      {currentPlayer.role !== 'admin' && !currentPlayer.partnerId && (
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-gradient-to-br from-[#1E293B] to-[#1E293B]/90 border border-[#BEF264]/30 rounded-3xl p-5 shadow-xl space-y-4 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-24 h-24 bg-[#BEF264]/10 rounded-full blur-xl"></div>
          <div className="flex items-start gap-3">
            <div className="p-2.5 bg-[#BEF264]/10 text-[#BEF264] rounded-xl border border-[#BEF264]/20 shrink-0">
              <UserIcon className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h3 className="font-extrabold text-sm text-white">¿Aún no tienes pareja asignada?</h3>
              <p className="text-xs text-slate-400 leading-normal">
                Selecciona tu compañero de juego para que podáis sumar puntos juntos en el ranking y competir en vuestra división.
              </p>
            </div>
          </div>

          {!isSelectingPartner ? (
            <button
              id="home_select_partner_trigger"
              onClick={() => setIsSelectingPartner(true)}
              className="w-full py-2.5 bg-[#BEF264] hover:opacity-90 text-slate-900 font-extrabold rounded-xl text-xs transition-all hover:scale-[1.01] flex items-center justify-center gap-1.5 cursor-pointer"
            >
              Selecciona tu pareja
            </button>
          ) : (
            <motion.div 
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="space-y-3 pt-2"
            >
              <div className="space-y-1.5">
                <label htmlFor="home_partner_select_dropdown" className="text-[10px] font-bold uppercase tracking-wider text-slate-400">Elige a tu compañero</label>
                <select
                  id="home_partner_select_dropdown"
                  value={homePartnerId}
                  onChange={(e) => setHomePartnerId(e.target.value)}
                  className="w-full px-3 py-2.5 bg-[#0F172A] border border-slate-700/50 rounded-xl text-xs focus:outline-none focus:border-[#BEF264] text-white transition-colors"
                >
                  <option value="">-- Elige un jugador del ranking --</option>
                  {playersList
                    .filter(p => p.id !== currentPlayer.id && p.role !== 'admin')
                    .map(p => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.division}) {p.partnerId ? '🔗' : ''}
                      </option>
                    ))}
                </select>
              </div>

              <div className="flex gap-2">
                <button
                  id="home_save_partner_btn"
                  type="button"
                  onClick={async () => {
                    if (!homePartnerId) return;
                    setLoading(true);
                    try {
                      await updatePlayerPartner(currentPlayer.id, homePartnerId);
                      setSuccessMsg('¡Pareja seleccionada correctamente!');
                      setIsSelectingPartner(false);
                      onMatchSubmitted(); // trigger refresh of profile
                    } catch (err) {
                      console.error(err);
                      setErrorMsg('Error al asignar pareja.');
                    } finally {
                      setLoading(false);
                    }
                  }}
                  disabled={!homePartnerId || loading}
                  className="flex-1 py-2 bg-[#BEF264] text-slate-900 font-extrabold rounded-xl text-xs transition-all hover:opacity-90 disabled:opacity-50 cursor-pointer"
                >
                  Confirmar Selección
                </button>
                <button
                  id="home_cancel_partner_btn"
                  type="button"
                  onClick={() => setIsSelectingPartner(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-750 text-slate-300 font-bold rounded-xl text-xs transition-all cursor-pointer"
                >
                  Cancelar
                </button>
              </div>
            </motion.div>
          )}
        </motion.div>
      )}

      {/* Success Banner */}
      {successMsg && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex items-start gap-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 p-4 rounded-xl text-xs"
        >
          <CheckCircle className="w-5 h-5 shrink-0 text-emerald-400" />
          <div>
            <p className="font-bold">¡Guardado con éxito!</p>
            <p className="text-slate-300 mt-0.5">{successMsg}</p>
          </div>
        </motion.div>
      )}

      {/* Active Jornada & Countdown */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="bg-[#1E293B] border border-slate-700/50 rounded-3xl p-5 shadow-lg space-y-4"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-[#BEF264]" />
            <div>
              <h3 className="font-bold text-sm text-white">Jornada Activa</h3>
              <p className="text-xs text-slate-400 font-mono">
                {activeRound ? `${formatDate(activeRound.startDate)} al ${formatDate(activeRound.endDate)}` : 'Cargando...'}
              </p>
            </div>
          </div>
          {activeRound && (
            <div className="px-3 py-1 bg-[#BEF264]/10 text-[#BEF264] font-bold text-xs rounded-full border border-[#BEF264]/20 flex items-center gap-1">
              <Hash className="w-3.5 h-3.5" />
              <span>Jornada {activeRound.number}</span>
            </div>
          )}
        </div>

        {activeRound && (
          <div className="space-y-2">
            <div className="flex justify-between text-xs text-slate-400">
              <span className="font-semibold text-slate-300">{getDaysLeftString()}</span>
              <span>{Math.round(getRoundProgressPercent())}% transcurrido</span>
            </div>
            {/* Elegant progress bar */}
            <div className="w-full bg-[#0F172A] h-2 rounded-full overflow-hidden border border-slate-700/30">
              <div 
                className="bg-gradient-to-r from-[#BEF264] to-[#BEF264]/80 h-full rounded-full transition-all duration-500" 
                style={{ width: `${getRoundProgressPercent()}%` }}
              ></div>
            </div>
            <p className="text-[10px] text-slate-500 flex items-start gap-1 leading-normal pt-1">
              <Info className="w-3 h-3 text-[#BEF264] shrink-0 mt-0.5" />
              <span>
                Al concluir el tiempo, el sistema moverá automáticamente a los 2 mejores jugadores de división hacia arriba, y a los 2 últimos hacia abajo, reiniciando los puntos para la siguiente Jornada.
              </span>
            </p>
          </div>
        )}
      </motion.div>

      {/* Primary Action Button: Toggle Match Recorder */}
      <div className="flex justify-center">
        <button
          id="toggle_record_form_btn"
          onClick={() => setIsRecording(!isRecording)}
          className={`px-5 py-3.5 rounded-2xl text-sm font-bold shadow-lg flex items-center gap-2 cursor-pointer transition-all ${
            isRecording 
            ? 'bg-[#1E293B] border border-slate-700/50 text-white' 
            : 'bg-[#BEF264] hover:opacity-90 text-slate-900 font-extrabold hover:scale-[1.02]'
          }`}
        >
          <PlusCircle className="w-5 h-5" />
          {isRecording ? 'Cancelar Registro' : 'Apuntar Resultado de Partido'}
        </button>
      </div>

      {/* Match Recorder Form Container */}
      <AnimatePresence>
        {isRecording && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <form onSubmit={handleRecordMatch} className="bg-[#1E293B] border border-slate-700/50 rounded-3xl p-5 shadow-xl space-y-5">
              <h3 className="font-bold text-base text-white border-b border-slate-700/30 pb-3">Registrar Nuevo Partido</h3>
              
              {errorMsg && (
                <div className="flex items-start gap-2 bg-rose-500/10 border border-rose-500/30 text-rose-300 p-3 rounded-xl text-xs">
                  <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{errorMsg}</span>
                </div>
              )}

              {/* Step 1: Match Type Selection */}
              <div className="space-y-2">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">Modalidad de Juego</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    id="match_type_doubles"
                    type="button"
                    onClick={() => setMatchType('doubles')}
                    className={`p-3 rounded-xl border text-sm font-semibold transition-colors flex flex-col items-center gap-1 ${
                      matchType === 'doubles'
                        ? 'bg-[#BEF264]/10 border-[#BEF264]/40 text-[#BEF264]'
                        : 'bg-[#0F172A] border-slate-700/50 hover:border-slate-700 text-slate-400'
                    }`}
                  >
                    <span>Parejas (2 vs 2)</span>
                    <span className="text-[10px] text-slate-500 font-normal">Pádel estándar</span>
                  </button>
                  <button
                    id="match_type_singles"
                    type="button"
                    onClick={() => setMatchType('singles')}
                    className={`p-3 rounded-xl border text-sm font-semibold transition-colors flex flex-col items-center gap-1 ${
                      matchType === 'singles'
                        ? 'bg-[#BEF264]/10 border-[#BEF264]/40 text-[#BEF264]'
                        : 'bg-[#0F172A] border-slate-700/50 hover:border-slate-700 text-slate-400'
                    }`}
                  >
                    <span>Individuales (1 vs 1)</span>
                    <span className="text-[10px] text-slate-500 font-normal">Pádel mano a mano</span>
                  </button>
                </div>
              </div>

              {/* Step 2: Player Selections */}
              <div className="space-y-4">
                <div className="p-3 bg-[#0F172A]/60 rounded-xl border border-slate-700/30 space-y-3">
                  <span className="text-xs font-bold text-[#BEF264] uppercase tracking-widest block">Mi Equipo (Equipo 1)</span>
                  
                  <div className="space-y-1">
                    <label className="text-[11px] font-semibold text-slate-400">Jugador 1</label>
                    <div className="w-full px-3 py-2 bg-[#1E293B] border border-slate-700/30 rounded-lg text-sm text-slate-300 font-medium">
                      {currentPlayer.name} <span className="text-[10px] text-slate-500 font-mono">(Tú)</span>
                    </div>
                  </div>

                  {matchType === 'doubles' && (
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-slate-400" htmlFor="partner_select">Jugador 2 (Pareja)</label>
                      <select
                        id="partner_select"
                        value={partnerId}
                        onChange={(e) => setPartnerId(e.target.value)}
                        className="w-full px-3 py-2 bg-[#1E293B] border border-slate-700/50 rounded-lg text-sm text-white focus:outline-none focus:border-[#BEF264]"
                        required={matchType === 'doubles'}
                      >
                        <option value="">Selecciona pareja de {currentPlayer.division}</option>
                        {availablePlayersForSelect.map(p => (
                          <option key={p.id} value={p.id}>{p.name} ({p.division})</option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>

                <div className="p-3 bg-[#0F172A]/60 rounded-xl border border-slate-700/30 space-y-3">
                  <span className="text-xs font-bold text-rose-400 uppercase tracking-widest block">Rivales (Equipo 2)</span>
                  
                  <div className="grid grid-cols-1 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] font-semibold text-slate-400" htmlFor="opp1_select">Oponente 1</label>
                      <select
                        id="opp1_select"
                        value={opp1Id}
                        onChange={(e) => setOpp1Id(e.target.value)}
                        className="w-full px-3 py-2 bg-[#1E293B] border border-slate-700/50 rounded-lg text-sm text-white focus:outline-none focus:border-[#BEF264]"
                        required
                      >
                        <option value="">Selecciona oponente</option>
                        {availablePlayersForSelect
                          .filter(p => p.id !== partnerId)
                          .map(p => (
                            <option key={p.id} value={p.id}>{p.name} ({p.division})</option>
                          ))}
                      </select>
                    </div>

                    {matchType === 'doubles' && (
                      <div className="space-y-1">
                        <label className="text-[11px] font-semibold text-slate-400" htmlFor="opp2_select">Oponente 2</label>
                        <select
                          id="opp2_select"
                          value={opp2Id}
                          onChange={(e) => setOpp2Id(e.target.value)}
                          className="w-full px-3 py-2 bg-[#1E293B] border border-slate-700/50 rounded-lg text-sm text-white focus:outline-none focus:border-[#BEF264]"
                          required={matchType === 'doubles'}
                        >
                          <option value="">Selecciona oponente</option>
                          {availablePlayersForSelect
                            .filter(p => p.id !== partnerId && p.id !== opp1Id)
                            .map(p => (
                              <option key={p.id} value={p.id}>{p.name} ({p.division})</option>
                            ))}
                        </select>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Step 3: Score Entries */}
              <div className="space-y-3 border-t border-slate-700/30 pt-4">
                <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block">Resultado de Sets</label>
                
                <div className="grid grid-cols-3 gap-3">
                  {/* Set 1 */}
                  <div className="bg-[#0F172A] p-2.5 rounded-2xl border border-slate-700/50 text-center space-y-2">
                    <span className="text-[10px] text-slate-500 font-bold block uppercase">Set 1</span>
                    <div className="flex items-center justify-center gap-1.5">
                      <input
                        id="set1_t1"
                        type="number"
                        min="0"
                        max="7"
                        value={set1T1}
                        onChange={(e) => setSet1T1(parseInt(e.target.value) || 0)}
                        className="w-8 h-8 text-center bg-[#1E293B] border border-slate-700/50 rounded-md text-sm text-[#BEF264] font-bold focus:outline-none"
                      />
                      <span className="text-slate-600">-</span>
                      <input
                        id="set1_t2"
                        type="number"
                        min="0"
                        max="7"
                        value={set1T2}
                        onChange={(e) => setSet1T2(parseInt(e.target.value) || 0)}
                        className="w-8 h-8 text-center bg-[#1E293B] border border-slate-700/50 rounded-md text-sm text-rose-400 font-bold focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Set 2 */}
                  <div className="bg-[#0F172A] p-2.5 rounded-2xl border border-slate-700/50 text-center space-y-2">
                    <span className="text-[10px] text-slate-500 font-bold block uppercase">Set 2</span>
                    <div className="flex items-center justify-center gap-1.5">
                      <input
                        id="set2_t1"
                        type="number"
                        min="0"
                        max="7"
                        value={set2T1}
                        onChange={(e) => setSet2T1(parseInt(e.target.value) || 0)}
                        className="w-8 h-8 text-center bg-[#1E293B] border border-slate-700/50 rounded-md text-sm text-[#BEF264] font-bold focus:outline-none"
                      />
                      <span className="text-slate-600">-</span>
                      <input
                        id="set2_t2"
                        type="number"
                        min="0"
                        max="7"
                        value={set2T2}
                        onChange={(e) => setSet2T2(parseInt(e.target.value) || 0)}
                        className="w-8 h-8 text-center bg-[#1E293B] border border-slate-700/50 rounded-md text-sm text-rose-400 font-bold focus:outline-none"
                      />
                    </div>
                  </div>

                  {/* Set 3 (Optional or Conditional) */}
                  <div className={`bg-[#0F172A] p-2.5 rounded-2xl border text-center transition-all ${
                    isSet3Required 
                      ? 'border-slate-700/50' 
                      : 'border-slate-800/30 opacity-30 select-none'
                  }`}>
                    <span className="text-[10px] text-slate-500 font-bold block uppercase">Set 3 {isSet3Required ? '' : '(Diferido)'}</span>
                    <div className="flex items-center justify-center gap-1.5 mt-2">
                      <input
                        id="set3_t1"
                        type="number"
                        min="0"
                        max="7"
                        disabled={!isSet3Required}
                        value={set3T1}
                        onChange={(e) => setSet3T1(parseInt(e.target.value) || 0)}
                        className="w-8 h-8 text-center bg-[#1E293B] border border-slate-700/50 rounded-md text-sm text-[#BEF264] font-bold focus:outline-none disabled:opacity-50"
                      />
                      <span className="text-slate-600">-</span>
                      <input
                        id="set3_t2"
                        type="number"
                        min="0"
                        max="7"
                        disabled={!isSet3Required}
                        value={set3T2}
                        onChange={(e) => setSet3T2(parseInt(e.target.value) || 0)}
                        className="w-8 h-8 text-center bg-[#1E293B] border border-slate-700/50 rounded-md text-sm text-rose-400 font-bold focus:outline-none disabled:opacity-50"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Submit Action */}
              <button
                id="submit_match_btn"
                type="submit"
                disabled={loading}
                className="w-full py-3 bg-[#BEF264] hover:opacity-90 disabled:bg-slate-800 text-slate-900 font-extrabold rounded-xl text-sm transition-all hover:scale-[1.01] active:scale-[0.99] flex items-center justify-center gap-2 cursor-pointer"
              >
                {loading ? (
                  <span className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-slate-950 border-t-transparent"></span>
                ) : (
                  'Confirmar y Guardar Resultado'
                )}
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Quick Tips */}
      <div className="bg-[#1E293B]/40 border border-slate-700/30 p-4 rounded-3xl space-y-2">
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
          <Info className="w-3.5 h-3.5 text-[#BEF264]" />
          ¿Cómo funciona la puntuación?
        </h4>
        <ul className="text-[11px] text-slate-400 space-y-1 list-disc list-inside">
          <li>Participar en un partido te asegura <span className="text-white">+1 punto</span>.</li>
          <li>Cada set individual que gane tu equipo te suma <span className="text-white">+1 punto</span>.</li>
          <li>Llevaros la victoria del partido os otorga <span className="text-white font-bold text-[#BEF264]">+3 puntos extra</span>.</li>
          <li>El equipo perdedor puede rascar un punto extra si logra forzar el tercer set!</li>
        </ul>
      </div>

    </div>
  );
}
