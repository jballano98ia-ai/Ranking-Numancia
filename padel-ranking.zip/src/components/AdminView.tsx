import React, { useState, useEffect } from 'react';
import { Player, Round } from '../types';
import { getActiveRound, getRounds, closeCurrentRound, seedDatabase, getPlayers, handleFirestoreError, OperationType, updatePlayerPartner } from '../lib/db';
import { db } from '../lib/firebase';
import { collection, addDoc, getDocs, doc, writeBatch, serverTimestamp } from 'firebase/firestore';
import { 
  ShieldAlert, 
  RefreshCw, 
  Calendar, 
  UserPlus, 
  History, 
  Trash2, 
  CheckCircle,
  TrendingUp,
  TrendingDown,
  ArrowRightLeft,
  Users,
  Link2Off
} from 'lucide-react';
import { motion } from 'motion/react';

interface AdminViewProps {
  currentPlayer: Player;
  onAdminActionCompleted: () => void;
}

export default function AdminView({ currentPlayer, onAdminActionCompleted }: AdminViewProps) {
  const [activeRound, setActiveRound] = useState<Round | null>(null);
  const [roundsList, setRoundsList] = useState<Round[]>([]);
  const [playersList, setPlayersList] = useState<Player[]>([]);
  const [loading, setLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  // New Player Form
  const [newPlayerName, setNewPlayerName] = useState('');
  const [newPlayerEmail, setNewPlayerEmail] = useState('');
  const [newPlayerDivision, setNewPlayerDivision] = useState('División 3');

  // Load round data
  useEffect(() => {
    async function loadAdminData() {
      try {
        const active = await getActiveRound();
        setActiveRound(active);
        
        const list = await getRounds();
        setRoundsList(list);

        const allPlayers = await getPlayers();
        setPlayersList(allPlayers.filter(p => p.role !== 'admin'));
      } catch (err) {
        console.error('Error loading admin data:', err);
      }
    }
    loadAdminData();
  }, [loading]);

  const handleCloseRound = async () => {
    if (!activeRound) return;
    if (!window.confirm(`¿Estás seguro de que deseas cerrar la Jornada ${activeRound.number}? Esto moverá a los jugadores de grupo automáticamente según sus resultados actuales y reseteará los marcadores para la Jornada ${activeRound.number + 1}.`)) {
      return;
    }

    setLoading(true);
    setErrorMsg('');
    setSuccessMsg('');

    try {
      const nextRoundId = await closeCurrentRound(activeRound.id, 7);
      setSuccessMsg(`¡Jornada ${activeRound.number} cerrada con éxito! Los ascensos/descensos han sido aplicados y se ha iniciado la Jornada ${activeRound.number + 1}.`);
      onAdminActionCompleted();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error al cerrar la jornada.');
    } finally {
      setLoading(false);
    }
  };

  const handleAddPlayer = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg('');
    setSuccessMsg('');

    try {
      if (!newPlayerName.trim() || !newPlayerEmail.trim()) {
        throw new Error('Por favor, rellena todos los campos.');
      }

      const playerId = `player_${Date.now()}`;
      const playerRef = doc(db, 'players', playerId);

      const newPlayer: Player = {
        id: playerId,
        name: newPlayerName.trim(),
        email: newPlayerEmail.trim().toLowerCase(),
        division: newPlayerDivision,
        points: 0,
        played: 0,
        won: 0,
        lost: 0,
        setsWon: 0,
        setsLost: 0,
        gamesWon: 0,
        gamesLost: 0,
        role: 'player'
      };

      const batch = writeBatch(db);
      batch.set(playerRef, {
        ...newPlayer,
        createdAt: serverTimestamp()
      });

      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.WRITE, `players/${playerId}`);
      }

      setSuccessMsg(`¡Jugador "${newPlayerName}" añadido correctamente a la ${newPlayerDivision}!`);
      setNewPlayerName('');
      setNewPlayerEmail('');
      onAdminActionCompleted();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Error al agregar jugador.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetDatabase = async () => {
    if (!window.confirm('¿Estás seguro de que quieres restablecer la base de datos? Se borrarán todos los partidos jugados y los jugadores volverán a su estado inicial de prueba.')) {
      return;
    }

    setLoading(true);
    setErrorMsg('');
    setSuccessMsg('');

    try {
      // 1. Delete players
      let pSnap;
      try {
        const playersCol = collection(db, 'players');
        pSnap = await getDocs(playersCol);
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'players');
      }

      // 2. Delete matches
      let mSnap;
      try {
        const matchesCol = collection(db, 'matches');
        mSnap = await getDocs(matchesCol);
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'matches');
      }

      // 3. Delete rounds
      let rSnap;
      try {
        const roundsCol = collection(db, 'rounds');
        rSnap = await getDocs(roundsCol);
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'rounds');
      }

      const batch = writeBatch(db);
      
      pSnap.docs.forEach(doc => {
        batch.delete(doc.ref);
      });

      mSnap.docs.forEach(doc => {
        batch.delete(doc.ref);
      });

      rSnap.docs.forEach(doc => {
        batch.delete(doc.ref);
      });

      try {
        await batch.commit();
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, 'reset_batch');
      }

      // 4. Re-seed default values
      await seedDatabase();

      setSuccessMsg('¡Base de datos restablecida correctamente al estado de simulación estándar!');
      onAdminActionCompleted();
    } catch (err: any) {
      console.error(err);
      setErrorMsg('Error al restablecer la base de datos.');
    } finally {
      setLoading(false);
    }
  };

  // Completed rounds filter
  const completedRounds = roundsList.filter(r => r.status === 'completed');

  return (
    <div id="admin_view_container" className="space-y-6 pb-24 text-white p-4">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
          <ShieldAlert className="w-5 h-5 text-[#BEF264]" />
          Panel de Administración
        </h2>
        <p className="text-xs text-slate-400">Controla las rondas de la liga y los jugadores</p>
      </div>

      {/* Action outcomes alerts */}
      {successMsg && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex items-start gap-2 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 p-4 rounded-xl text-xs"
        >
          <CheckCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{successMsg}</span>
        </motion.div>
      )}

      {errorMsg && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex items-start gap-2 bg-rose-500/10 border border-rose-500/30 text-rose-300 p-4 rounded-xl text-xs"
        >
          <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
          <span>{errorMsg}</span>
        </motion.div>
      )}

      {/* Close Round Section */}
      <div className="bg-[#1E293B] border border-slate-700/50 rounded-3xl p-5 space-y-4 shadow-xl">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/30 pb-3">
          <RefreshCw className="w-4.5 h-4.5 text-[#BEF264]" />
          Cierre y Mover Grupos
        </h3>
        
        {activeRound ? (
          <div className="space-y-4 text-xs">
            <p className="text-slate-400 leading-relaxed">
              Haz clic aquí para forzar manualmente el final de la <strong className="text-white">Jornada {activeRound.number}</strong>. El sistema procesará todos los partidos jugados hasta ahora, actualizará las divisiones de los jugadores (ascensos y descensos automáticos) e iniciará la siguiente jornada con los puntos a 0.
            </p>
            <button
              id="admin_close_round_btn"
              onClick={handleCloseRound}
              disabled={loading}
              className="w-full py-3 bg-rose-500/10 hover:bg-rose-500 hover:text-slate-950 text-rose-400 font-bold border border-rose-500/30 hover:border-transparent rounded-2xl transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <span className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-current border-t-transparent"></span>
              ) : (
                'Cerrar Jornada Actual y Ejecutar Ascensos'
              )}
            </button>
          </div>
        ) : (
          <p className="text-xs text-slate-500">No hay ninguna jornada activa para cerrar.</p>
        )}
      </div>

      {/* Add New Player */}
      <div className="bg-[#1E293B] border border-slate-700/50 rounded-3xl p-5 space-y-4 shadow-xl">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/30 pb-3">
          <UserPlus className="w-4.5 h-4.5 text-[#BEF264]" />
          Inscribir Nuevo Jugador
        </h3>

        <form onSubmit={handleAddPlayer} className="space-y-3 text-xs">
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1">
              <label htmlFor="admin_new_player_name" className="text-[10px] font-semibold text-slate-400">Nombre</label>
              <input
                id="admin_new_player_name"
                type="text"
                placeholder="Ej. Juan Martín Diaz"
                value={newPlayerName}
                onChange={(e) => setNewPlayerName(e.target.value)}
                className="w-full px-3 py-2.5 bg-[#0F172A] border border-slate-700/50 rounded-xl text-white text-xs focus:outline-none focus:border-[#BEF264]"
                required
              />
            </div>
            <div className="space-y-1">
              <label htmlFor="admin_new_player_email" className="text-[10px] font-semibold text-slate-400">Email</label>
              <input
                id="admin_new_player_email"
                type="email"
                placeholder="juan@email.com"
                value={newPlayerEmail}
                onChange={(e) => setNewPlayerEmail(e.target.value)}
                className="w-full px-3 py-2.5 bg-[#0F172A] border border-slate-700/50 rounded-xl text-white text-xs focus:outline-none focus:border-[#BEF264]"
                required
              />
            </div>
          </div>

          <div className="space-y-1">
            <label htmlFor="admin_new_player_div" className="text-[10px] font-semibold text-slate-400">División de Entrada</label>
            <select
              id="admin_new_player_div"
              value={newPlayerDivision}
              onChange={(e) => setNewPlayerDivision(e.target.value)}
              className="w-full px-3 py-2.5 bg-[#0F172A] border border-slate-700/50 rounded-xl text-white text-xs focus:outline-none focus:border-[#BEF264]"
            >
              <option value="División 1">División 1</option>
              <option value="División 2">División 2</option>
              <option value="División 3">División 3</option>
            </select>
          </div>

          <button
            id="admin_add_player_btn"
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-[#BEF264] text-slate-900 font-extrabold rounded-2xl transition-all hover:opacity-90 cursor-pointer"
          >
            Agregar Jugador a la Liga
          </button>
        </form>
      </div>

      {/* Gestión de Parejas */}
      <div className="bg-[#1E293B] border border-slate-700/50 rounded-3xl p-5 space-y-4 shadow-xl">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/30 pb-3">
          <Users className="w-4.5 h-4.5 text-[#BEF264]" />
          Gestión de Parejas (Admin)
        </h3>
        
        <p className="text-xs text-slate-400">
          Como administrador, puedes romper o restablecer las vinculaciones de pareja de cualquier jugador para permitirles volver a elegir una nueva pareja en su página de Inicio.
        </p>

        <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
          {playersList.length === 0 ? (
            <p className="text-xs text-slate-500">Cargando lista de jugadores...</p>
          ) : (
            playersList.map((p) => {
              const partner = p.partnerId ? playersList.find(other => other.id === p.partnerId) : null;
              return (
                <div key={p.id} className="flex justify-between items-center p-3 bg-[#0F172A]/50 border border-slate-700/30 rounded-2xl">
                  <div className="space-y-1">
                    <span className="text-[10px] uppercase font-mono font-bold text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded mr-2">
                      {p.division}
                    </span>
                    <span className="text-xs font-bold text-white">{p.name}</span>
                    <div className="text-xs text-slate-400">
                      {partner ? (
                        <span className="text-emerald-400 flex items-center gap-1 mt-0.5">
                          🔗 Pareja actual: {partner.name}
                        </span>
                      ) : (
                        <span className="text-slate-500 flex items-center gap-1 mt-0.5">
                          ❌ Sin pareja seleccionada
                        </span>
                      )}
                    </div>
                  </div>
                  {p.partnerId && (
                    <button
                      id={`reset_partner_btn_${p.id}`}
                      type="button"
                      onClick={async () => {
                        if (!window.confirm(`¿Estás seguro de que quieres desvincular a ${p.name} y ${partner ? partner.name : 'su pareja'}? Esto les permitirá elegir pareja de nuevo.`)) {
                          return;
                        }
                        setLoading(true);
                        try {
                          await updatePlayerPartner(p.id, null);
                          setSuccessMsg(`Parejas desvinculadas con éxito.`);
                          onAdminActionCompleted();
                        } catch (err) {
                          console.error(err);
                          setErrorMsg('Error al desvincular pareja.');
                        } finally {
                          setLoading(false);
                        }
                      }}
                      className="p-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 rounded-xl transition-all cursor-pointer border border-rose-500/20"
                      title="Desvincular Pareja"
                    >
                      <Link2Off className="w-4 h-4" />
                    </button>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Round History (Promotions / Demotions) */}
      <div className="bg-[#1E293B] border border-slate-700/50 rounded-3xl p-5 space-y-4 shadow-xl">
        <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-700/30 pb-3">
          <History className="w-4.5 h-4.5 text-[#BEF264]" />
          Histórico de Movimientos
        </h3>

        {completedRounds.length === 0 ? (
          <p className="text-xs text-slate-500">Aún no se ha cerrado ninguna jornada en esta simulación.</p>
        ) : (
          <div className="space-y-3">
            {completedRounds.map((round) => (
              <div key={round.id} className="p-3 bg-[#0F172A]/60 border border-slate-700/30 rounded-2xl space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-white">Jornada {round.number} cerrada</span>
                  <span className="text-[10px] font-mono text-slate-500">
                    {new Date(round.endDate).toLocaleDateString('es-ES')}
                  </span>
                </div>
                
                {/* Movement list */}
                <div className="space-y-1 text-[10.5px]">
                  {round.promotionsDemotions && round.promotionsDemotions.length > 0 ? (
                    round.promotionsDemotions
                      .filter(h => h.type !== 'stayed')
                      .map((h, idx) => {
                        const isPromo = h.type === 'promoted';
                        return (
                          <div key={idx} className="flex items-center justify-between text-slate-300">
                            <span className="truncate max-w-[120px] font-medium">{h.playerName}</span>
                            <div className="flex items-center gap-1">
                              <span className="text-[9px] text-slate-500">{h.fromDivision}</span>
                              <ArrowRightLeft className="w-3 h-3 text-slate-600" />
                              <span className={`font-semibold ${isPromo ? 'text-[#BEF264]' : 'text-rose-400'}`}>
                                {h.toDivision}
                              </span>
                              {isPromo ? (
                                <TrendingUp className="w-3.5 h-3.5 text-[#BEF264] shrink-0" />
                              ) : (
                                <TrendingDown className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                              )}
                            </div>
                          </div>
                        );
                      })
                  ) : (
                    <span className="text-slate-500 italic block">Sin promociones ni descensos registrados en esta ronda.</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Dangerous/Reset operations */}
      <div className="bg-[#0F172A]/50 p-4 border border-rose-950/55 rounded-3xl space-y-3 text-xs">
        <h4 className="font-bold text-rose-400 flex items-center gap-1 uppercase tracking-wider text-[10px]">
          <Trash2 className="w-4 h-4 text-rose-400" />
          Acciones Peligrosas / Desarrollo
        </h4>
        <p className="text-[11px] text-slate-400 leading-relaxed">
          Usa esta opción si deseas borrar todos los partidos simulados, deshacer cualquier cambio de división, y reiniciar los 12 jugadores de prueba al estado inicial óptimo para volver a probar.
        </p>
        <button
          id="admin_reset_db_btn"
          onClick={handleResetDatabase}
          disabled={loading}
          className="w-full py-2.5 bg-rose-500/10 hover:bg-rose-600 hover:text-white text-rose-400 border border-rose-500/20 hover:border-transparent font-semibold rounded-2xl transition-all cursor-pointer text-xs"
        >
          Restablecer Base de Datos de Prueba
        </button>
      </div>

    </div>
  );
}
