import React from 'react';
import { Home, Calendar, Trophy, BookOpen, ShieldAlert, LogOut } from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isAdmin: boolean;
  onLogout: () => void;
}

export default function Navigation({ activeTab, setActiveTab, isAdmin, onLogout }: NavigationProps) {
  const tabs = [
    { id: 'home', label: 'Inicio', icon: <Home className="w-5 h-5" /> },
    { id: 'matches', label: 'Partidos', icon: <Calendar className="w-5 h-5" /> },
    { id: 'ranking', label: 'Ranking', icon: <Trophy className="w-5 h-5" /> },
    { id: 'rules', label: 'Normas', icon: <BookOpen className="w-5 h-5" /> },
    ...(isAdmin ? [{ id: 'admin', label: 'Gestión', icon: <ShieldAlert className="w-5 h-5" /> }] : []),
  ];

  return (
    <nav 
      id="bottom_navigation_bar" 
      className="fixed bottom-0 left-0 right-0 bg-[#1E293B]/95 backdrop-blur-md border-t border-slate-700/50 px-4 py-2 z-40 flex justify-around items-center max-w-md mx-auto rounded-t-2xl shadow-xl shadow-[#BEF264]/5"
    >
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            id={`nav_tab_${tab.id}`}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center gap-1 py-1 px-2.5 rounded-xl transition-all cursor-pointer ${
              isActive 
                ? 'text-[#BEF264] bg-[#BEF264]/10 border border-[#BEF264]/20 scale-105' 
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {tab.icon}
            <span className="text-[10px] font-bold tracking-tight">{tab.label}</span>
          </button>
        );
      })}

      {/* Logout button placed in bottom nav for direct access */}
      <button
        id="nav_logout_btn"
        onClick={onLogout}
        className="flex flex-col items-center gap-1 py-1 px-2.5 text-slate-400 hover:text-rose-400 rounded-xl transition-colors cursor-pointer"
        title="Cerrar Sesión"
      >
        <LogOut className="w-5 h-5" />
        <span className="text-[10px] font-bold tracking-tight">Salir</span>
      </button>
    </nav>
  );
}
