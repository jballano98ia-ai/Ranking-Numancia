import React, { useState, useEffect } from 'react';
import { Match, Player } from '../types';
import { getMatches, getPlayers } from '../lib/db';
import { Award, Layers, Users, User, Calendar, ShieldAlert } from 'lucide-react';
import { motion } from 'motion/react';

interface MatchesViewProps {
  currentPlayer: Player;
  refreshTrigger: number;
}

export default function MatchesView({ currentPlayer, refreshTrigger }: MatchesViewProps) {
  const [matches, setMatches] = useState<Match[]>([]);
  const [filterDivision, setFilterDivision] = useState<string>('Todas');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchMatches() {
      setLoading(true);
      try {
        const list = await getMatches();
        setMatches(list);
      } catch (err) {
        console.error('Error fetching matches:', err);
      } finally {
        setLoading(false);
      }
    }
    fetchMatches();
  }, [refreshTrigger]);

  // Determine filtering
  const divisions = ['Todas', 'División 1', 'División 2', 'División 3'];
  
  const filteredMatches = filterDivision === 'Todas'
    ? matches
    : matches.filter(m => m.division === filterDivision);

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString('es-ES', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div id="matches_view_container" className="space-y-6 pb-24 text-white p-4">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <h2 className="text-xl font-bold tracking-tight text-white">Historial de Partidos</h2>
        <p className="text-xs text-slate-400">Consulta los resultados y puntos otorgados en las jornadas</p>
      </div>

      {/* Division Selector Tabs */}
      <div className="flex bg-[#1E293B] p-1.5 rounded-2xl border border-slate-700/50 overflow-x-auto scrollbar-none">
        {divisions.map((div) => (
          <button
            key={div}
            id={`filter_division_${div.replace(/\s+/g, '_')}`}
            onClick={() => setFilterDivision(div)}
            className={`flex-1 py-2 px-3 text-xs font-semibold rounded-xl whitespace-nowrap transition-colors cursor-pointer ${
              filterDivision === div
                ? 'bg-[#0F172A] text-[#BEF264] border border-slate-700/50'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {div}
          </button>
        ))}
      </div>

      {/* Matches List */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-8 w-8 border-4 border-[#BEF264] border-t-transparent"></div>
        </div>
      ) : filteredMatches.length === 0 ? (
        <div className="bg-[#1E293B] border border-dashed border-slate-700/50 rounded-3xl p-10 text-center space-y-3">
          <ShieldAlert className="w-10 h-10 text-slate-600 mx-auto" />
          <h3 className="font-bold text-sm text-slate-300">No hay partidos registrados</h3>
          <p className="text-xs text-slate-500 max-w-xs mx-auto leading-normal">
            Aún no se han anotado resultados en {filterDivision === 'Todas' ? 'ninguna división' : filterDivision}. ¡Sé el primero en apuntar un partido!
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMatches.map((match, idx) => {
            const isWinnerT1 = match.winnerTeam === 1;
            
            return (
              <motion.div
                key={match.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: Math.min(idx * 0.05, 0.4) }}
                className="bg-[#1E293B] border border-slate-700/30 rounded-3xl overflow-hidden shadow-md"
              >
                {/* Match Header metadata */}
                <div className="bg-[#0F172A]/60 px-4 py-2 flex items-center justify-between border-b border-slate-700/30">
                  <div className="flex items-center gap-1.5 text-[10px] uppercase font-bold tracking-widest text-[#BEF264]">
                    {match.type === 'doubles' ? (
                      <Users className="w-3.5 h-3.5" />
                    ) : (
                      <User className="w-3.5 h-3.5" />
                    )}
                    <span>{match.type === 'doubles' ? 'Dobles' : 'Individual'}</span>
                    <span className="text-slate-600">•</span>
                    <span className="text-slate-400 font-mono text-[9px]">{match.division}</span>
                  </div>
                  <div className="text-[9px] text-slate-500 font-mono flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {formatDate(match.date)}
                  </div>
                </div>

                {/* Score panel */}
                <div className="p-4 grid grid-cols-12 gap-2 items-center">
                  
                  {/* Team 1 Players & Status */}
                  <div className="col-span-4 space-y-1.5">
                    {match.team1.map((pId) => (
                      <div 
                        key={pId} 
                        className={`text-xs font-semibold truncate ${
                          pId === currentPlayer.id ? 'text-[#BEF264] font-bold underline decoration-[#BEF264]/50' : 'text-slate-200'
                        }`}
                      >
                        {match.playerNames[pId] || 'Jugador'}
                      </div>
                    ))}
                    <div className="flex items-center gap-1">
                      <span className={`px-1.5 py-0.5 text-[9px] font-bold rounded ${
                        isWinnerT1 
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                          : 'bg-[#0F172A] text-slate-500'
                      }`}>
                        {isWinnerT1 ? 'VENCEDOR' : 'DERROTA'}
                      </span>
                    </div>
                  </div>

                  {/* Set values - center */}
                  <div className="col-span-4 flex items-center justify-center gap-2 bg-[#0F172A]/40 p-2 rounded-xl border border-slate-700/30">
                    <div className="flex flex-col items-center">
                      <span className={`text-base font-extrabold ${isWinnerT1 ? 'text-[#BEF264]' : 'text-slate-500'}`}>
                        {isWinnerT1 ? 2 : match.score.set3 ? 1 : 0}
                      </span>
                      <span className="text-[8px] uppercase font-semibold text-slate-600">Sets</span>
                    </div>

                    {/* Score detail popup style */}
                    <div className="flex items-center gap-1.5 px-2 py-1 bg-[#0F172A] border border-slate-700/50 rounded-lg text-xs font-mono font-bold text-white">
                      <span>{match.score.set1[0]}-{match.score.set1[1]}</span>
                      <span className="text-slate-700">,</span>
                      <span>{match.score.set2[0]}-{match.score.set2[1]}</span>
                      {match.score.set3 && (
                        <>
                          <span className="text-slate-700">,</span>
                          <span>{match.score.set3[0]}-{match.score.set3[1]}</span>
                        </>
                      )}
                    </div>

                    <div className="flex flex-col items-center">
                      <span className={`text-base font-extrabold ${!isWinnerT1 ? 'text-[#BEF264]' : 'text-slate-500'}`}>
                        {!isWinnerT1 ? 2 : match.score.set3 ? 1 : 0}
                      </span>
                      <span className="text-[8px] uppercase font-semibold text-slate-600">Sets</span>
                    </div>
                  </div>

                  {/* Team 2 Players & Status */}
                  <div className="col-span-4 text-right space-y-1.5">
                    {match.team2.map((pId) => (
                      <div 
                        key={pId} 
                        className={`text-xs font-semibold truncate ${
                          pId === currentPlayer.id ? 'text-[#BEF264] font-bold underline decoration-[#BEF264]/50' : 'text-slate-200'
                        }`}
                      >
                        {match.playerNames[pId] || 'Jugador'}
                      </div>
                    ))}
                    <div className="flex items-center justify-end gap-1">
                      <span className={`px-1.5 py-0.5 text-[9px] font-bold rounded ${
                        !isWinnerT1 
                          ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
                          : 'bg-[#0F172A] text-slate-500'
                      }`}>
                        {!isWinnerT1 ? 'VENCEDOR' : 'DERROTA'}
                      </span>
                    </div>
                  </div>

                </div>

                {/* Points Awarded Footer */}
                <div className="bg-[#0F172A]/40 px-4 py-2 border-t border-slate-700/30 text-[10px] text-slate-400 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Award className="w-3.5 h-3.5 text-[#BEF264]" />
                    Reparto de Puntos Ranking:
                  </span>
                  <div className="flex gap-2 flex-wrap justify-end font-mono">
                    {Object.entries(match.pointsAwarded || {}).map(([pId, pts]) => {
                      const name = match.playerNames[pId] ? match.playerNames[pId].split(' ')[0] : 'Jugador';
                      return (
                        <span key={pId} className="bg-[#1E293B] border border-slate-700/30 px-1.5 py-0.5 rounded text-[9px]">
                          {name}: <strong className="text-[#BEF264]">+{pts}</strong>
                        </span>
                      );
                    })}
                  </div>
                </div>

              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
