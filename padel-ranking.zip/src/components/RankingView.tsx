import React, { useState, useEffect } from 'react';
import { Player } from '../types';
import { getPlayers, sortPlayersForRanking } from '../lib/db';
import { 
  Trophy, 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Medal, 
  ShieldAlert,
  Search,
  Star
} from 'lucide-react';
import { motion } from 'motion/react';

interface RankingViewProps {
  currentPlayer: Player;
  refreshTrigger: number;
}

export default function RankingView({ currentPlayer, refreshTrigger }: RankingViewProps) {
  const [players, setPlayers] = useState<Player[]>([]);
  const [selectedDivision, setSelectedDivision] = useState<string>(currentPlayer.division);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    async function loadPlayers() {
      setLoading(true);
      try {
        const list = await getPlayers();
        setPlayers(list);
      } catch (err) {
        console.error('Error loading players:', err);
      } finally {
        setLoading(false);
      }
    }
    loadPlayers();
  }, [refreshTrigger]);

  const divisions = ['División 1', 'División 2', 'División 3'];

  // Known seeded couples mapping
  const SEEDED_PARTNERS: { [id: string]: string } = {
    'p_galan': 'p_lebron',
    'p_lebron': 'p_galan',
    'p_coello': 'p_tapia',
    'p_tapia': 'p_coello',
    'p_navarro': 'p_dinenno',
    'p_dinenno': 'p_navarro',
    'p_bela': 'p_sanyo',
    'p_sanyo': 'p_bela',
    'p_stupa': 'p_chingotto',
    'p_chingotto': 'p_stupa',
    'p_momo': 'p_ruiz',
    'p_ruiz': 'p_momo',
    'p_yanguas': 'p_garrido',
    'p_garrido': 'p_yanguas',
    'p_nieto': 'p_sanz',
    'p_sanz': 'p_nieto',
    'p_rubio': 'p_jruiz',
    'p_jruiz': 'p_rubio',
  };

  interface Couple {
    id: string;
    player1: Player;
    player2: Player;
    name: string;
    division: string;
    points: number;
    played: number;
    won: number;
    lost: number;
    setsWon: number;
    setsLost: number;
    gamesWon: number;
    gamesLost: number;
  }

  // Group players into couples
  const getCouples = (allPlayers: Player[]): Couple[] => {
    const nonAdmins = allPlayers.filter(p => p.role !== 'admin');
    const couplesList: Couple[] = [];
    const processedIds = new Set<string>();

    // 1. First pair up players using the DB partnerId or fallback SEEDED_PARTNERS mapping
    nonAdmins.forEach(p => {
      if (processedIds.has(p.id)) return;
      const partnerId = p.partnerId || SEEDED_PARTNERS[p.id];
      if (partnerId) {
        const partner = nonAdmins.find(other => other.id === partnerId);
        if (partner && !processedIds.has(partner.id)) {
          processedIds.add(p.id);
          processedIds.add(partner.id);
          
          const [p1, p2] = p.id < partner.id ? [p, partner] : [partner, p];
          
          couplesList.push({
            id: `couple_${p1.id}_${p2.id}`,
            player1: p1,
            player2: p2,
            name: `${p1.name} / ${p2.name}`,
            division: p1.division,
            points: Math.round((p1.points + p2.points) / 2),
            played: Math.round((p1.played + p2.played) / 2),
            won: Math.round((p1.won + p2.won) / 2),
            lost: Math.round((p1.lost + p2.lost) / 2),
            setsWon: Math.round((p1.setsWon + p2.setsWon) / 2),
            setsLost: Math.round((p1.setsLost + p2.setsLost) / 2),
            gamesWon: Math.round((p1.gamesWon + p2.gamesWon) / 2),
            gamesLost: Math.round((p1.gamesLost + p2.gamesLost) / 2),
          });
        }
      }
    });

    // 2. For remaining non-admin players, group them by division and pair them 2-by-2
    const divisionsList = ['División 1', 'División 2', 'División 3'];
    divisionsList.forEach(div => {
      const remainingInDiv = nonAdmins.filter(p => !processedIds.has(p.id) && p.division === div);
      remainingInDiv.sort((a, b) => a.name.localeCompare(b.name));

      for (let i = 0; i < remainingInDiv.length; i += 2) {
        const p1 = remainingInDiv[i];
        const p2 = remainingInDiv[i + 1];

        if (p1 && p2) {
          processedIds.add(p1.id);
          processedIds.add(p2.id);
          couplesList.push({
            id: `couple_${p1.id}_${p2.id}`,
            player1: p1,
            player2: p2,
            name: `${p1.name} / ${p2.name}`,
            division: div,
            points: Math.round((p1.points + p2.points) / 2),
            played: Math.round((p1.played + p2.played) / 2),
            won: Math.round((p1.won + p2.won) / 2),
            lost: Math.round((p1.lost + p2.lost) / 2),
            setsWon: Math.round((p1.setsWon + p2.setsWon) / 2),
            setsLost: Math.round((p1.setsLost + p2.setsLost) / 2),
            gamesWon: Math.round((p1.gamesWon + p2.gamesWon) / 2),
            gamesLost: Math.round((p1.gamesLost + p2.gamesLost) / 2),
          });
        } else if (p1) {
          processedIds.add(p1.id);
          couplesList.push({
            id: `couple_${p1.id}_single`,
            player1: p1,
            player2: p1,
            name: `${p1.name} (Sin pareja)`,
            division: div,
            points: p1.points,
            played: p1.played,
            won: p1.won,
            lost: p1.lost,
            setsWon: p1.setsWon,
            setsLost: p1.setsLost,
            gamesWon: p1.gamesWon,
            gamesLost: p1.gamesLost,
          });
        }
      }
    });

    return couplesList;
  };

  const sortCouples = (couplesList: Couple[]): Couple[] => {
    return [...couplesList].sort((a, b) => {
      if (b.points !== a.points) return b.points - a.points;
      if (b.won !== a.won) return b.won - a.won;
      
      const diffA_sets = a.setsWon - a.setsLost;
      const diffB_sets = b.setsWon - b.setsLost;
      if (diffB_sets !== diffA_sets) return diffB_sets - diffA_sets;
      
      const diffA_games = a.gamesWon - a.gamesLost;
      const diffB_games = b.gamesWon - b.gamesLost;
      return diffB_games - diffA_games;
    });
  };

  const allCouples = getCouples(players);

  // Filter and sort couples in selected division
  const divisionCouples = allCouples.filter(c => c.division === selectedDivision);
  const sortedDivisionCouples = sortCouples(divisionCouples);

  // Search filter for division couples
  const finalCouples = searchQuery.trim() === ''
    ? sortedDivisionCouples
    : sortedDivisionCouples.filter(c => 
        c.name.toLowerCase().includes(searchQuery.toLowerCase())
      );

  // Global classification calculation
  const getGlobalSortedCouples = (couplesList: Couple[]) => {
    const div1 = couplesList.filter(c => c.division === 'División 1');
    const div2 = couplesList.filter(c => c.division === 'División 2');
    const div3 = couplesList.filter(c => c.division === 'División 3');
    
    return [
      ...sortCouples(div1),
      ...sortCouples(div2),
      ...sortCouples(div3)
    ];
  };

  const globalSortedCouples = getGlobalSortedCouples(allCouples);
  const filteredGlobalCouples = searchQuery.trim() === ''
    ? globalSortedCouples
    : globalSortedCouples.filter(c => 
        c.name.toLowerCase().includes(searchQuery.toLowerCase())
      );

  // Determine zones for a couple based on their index in the division array
  const getCoupleZoneInfo = (index: number, division: string, totalCount: number) => {
    if (division === 'División 1') {
      // Division 1: Bottom demotes (index 2 of 3)
      if (index === totalCount - 1 && totalCount > 1) {
        return {
          type: 'demotion',
          text: 'Zona de Descenso',
          className: 'border-l-4 border-rose-500 bg-rose-500/5',
          badgeClass: 'bg-rose-500/15 text-rose-400 border border-rose-500/20',
          icon: <TrendingDown className="w-4.5 h-4.5 text-rose-400" />
        };
      }
    } else if (division === 'División 2') {
      // Division 2: Top promotes (index 0), Bottom demotes (index 2 of 3)
      if (index === 0) {
        return {
          type: 'promotion',
          text: 'Zona de Ascenso',
          className: 'border-l-4 border-[#BEF264] bg-[#BEF264]/5',
          badgeClass: 'bg-[#BEF264]/15 text-[#BEF264] border border-[#BEF264]/20',
          icon: <TrendingUp className="w-4.5 h-4.5 text-[#BEF264]" />
        };
      }
      if (index === totalCount - 1 && totalCount > 1) {
        return {
          type: 'demotion',
          text: 'Zona de Descenso',
          className: 'border-l-4 border-rose-500 bg-rose-500/5',
          badgeClass: 'bg-rose-500/15 text-rose-400 border border-rose-500/20',
          icon: <TrendingDown className="w-4.5 h-4.5 text-rose-400" />
        };
      }
    } else if (division === 'División 3') {
      // Division 3: Top promotes (index 0)
      if (index === 0) {
        return {
          type: 'promotion',
          text: 'Zona de Ascenso',
          className: 'border-l-4 border-[#BEF264] bg-[#BEF264]/5',
          badgeClass: 'bg-[#BEF264]/15 text-[#BEF264] border border-[#BEF264]/20',
          icon: <TrendingUp className="w-4.5 h-4.5 text-[#BEF264]" />
        };
      }
    }

    return {
      type: 'stay',
      text: 'Mantiene División',
      className: 'border-l-4 border-transparent hover:bg-slate-700/40',
      badgeClass: 'bg-[#0F172A] text-slate-400 border border-slate-700/50',
      icon: <Minus className="w-4.5 h-4.5 text-slate-500" />
    };
  };

  return (
    <div id="ranking_view_container" className="space-y-5 pb-24 text-white p-4">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
          <Trophy className="w-5 h-5 text-[#BEF264]" />
          Clasificación por Parejas
        </h2>
        <p className="text-xs text-slate-400">Verifica las posiciones y zonas críticas en tiempo real</p>
      </div>

      {/* Division selection */}
      <div className="flex bg-[#1E293B] p-1.5 rounded-2xl border border-slate-700/50">
        {divisions.map((div) => (
          <button
            key={div}
            id={`rank_tab_${div.replace(/\s+/g, '_')}`}
            onClick={() => {
              setSelectedDivision(div);
              setSearchQuery('');
            }}
            className={`flex-1 py-2 text-xs font-bold rounded-xl transition-colors cursor-pointer ${
              selectedDivision === div
                ? 'bg-[#0F172A] text-[#BEF264] border border-slate-700/50'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {div}
          </button>
        ))}
      </div>

      {/* Search Bar */}
      <div className="relative">
        <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
          <Search className="w-4 h-4" />
        </span>
        <input
          id="ranking_search_input"
          type="text"
          placeholder="Buscar pareja o jugador..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full pl-9 pr-4 py-2.5 bg-[#0F172A] border border-slate-700/50 rounded-2xl text-xs text-slate-300 focus:outline-none focus:border-[#BEF264] transition-colors"
        />
      </div>

      {/* Leaderboard Grid */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="animate-spin rounded-full h-8 w-8 border-4 border-[#BEF264] border-t-transparent"></div>
        </div>
      ) : finalCouples.length === 0 ? (
        <div className="bg-[#1E293B] border border-slate-700/50 rounded-3xl p-10 text-center text-slate-400 text-xs">
          {searchQuery ? 'No se encontraron resultados para la búsqueda.' : 'No hay parejas registradas en esta división.'}
        </div>
      ) : (
        <div className="space-y-2">
          
          {/* Table Header Row */}
          <div className="grid grid-cols-12 px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-[#1E293B]/20 rounded-lg">
            <div className="col-span-1 text-center">Pos</div>
            <div className="col-span-6 pl-2">Pareja</div>
            <div className="col-span-1.5 text-center">PJ</div>
            <div className="col-span-1.5 text-center">W/L</div>
            <div className="col-span-2 text-right">Pts</div>
          </div>

          {/* List Rows */}
          {finalCouples.map((couple, index) => {
            // Find real overall division rank (if query is empty, it's just index + 1)
            const realRank = searchQuery.trim() === ''
              ? index + 1
              : sortedDivisionCouples.findIndex(c => c.id === couple.id) + 1;

            const zone = getCoupleZoneInfo(realRank - 1, selectedDivision, sortedDivisionCouples.length);

            // Icon/Decoration for top players
            const getRankIcon = (rank: number) => {
              if (rank === 1) return <Medal className="w-4 h-4 text-amber-400 shrink-0" />;
              if (rank === 2) return <Medal className="w-4 h-4 text-slate-300 shrink-0" />;
              if (rank === 3) return <Medal className="w-4 h-4 text-amber-600 shrink-0" />;
              return <span className="text-slate-500 font-mono font-bold text-xs">{rank}</span>;
            };

            const isCurrentUser = couple.player1.id === currentPlayer.id || couple.player2.id === currentPlayer.id;

            return (
              <motion.div
                key={couple.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: Math.min(index * 0.04, 0.4) }}
                id={`ranking_row_${couple.id}`}
                className={`grid grid-cols-12 items-center p-3 rounded-2xl transition-all border border-slate-700/30 bg-[#1E293B] ${zone.className} ${
                  isCurrentUser ? 'ring-1 ring-[#BEF264] bg-[#BEF264]/5' : ''
                }`}
              >
                {/* Pos */}
                <div className="col-span-1 flex items-center justify-center">
                  {getRankIcon(realRank)}
                </div>

                {/* Player Detail & Zone indicator */}
                <div className="col-span-6 pl-2 flex flex-col justify-center min-w-0">
                  <div className="flex items-start gap-1.5 min-w-0">
                    <div className="flex flex-col min-w-0">
                      <span className={`text-xs font-bold truncate ${isCurrentUser ? 'text-[#BEF264]' : 'text-slate-100'}`}>
                        {couple.player1.name}
                      </span>
                      {couple.id.endsWith('_single') ? (
                        <span className="text-[10px] text-slate-500 italic">
                          (Sin pareja)
                        </span>
                      ) : (
                        <span className={`text-xs font-semibold truncate ${isCurrentUser ? 'text-[#BEF264]/80' : 'text-slate-400'}`}>
                          {couple.player2.name}
                        </span>
                      )}
                    </div>
                    {isCurrentUser && (
                      <span className="px-1.5 py-0.5 bg-[#BEF264]/10 border border-[#BEF264]/30 text-[#BEF264] text-[8px] font-extrabold uppercase rounded tracking-wider shrink-0 font-sans mt-0.5">
                        Vuestra Pareja
                      </span>
                    )}
                  </div>
                  
                  {/* Small badge representing active zone status */}
                  <div className="flex items-center gap-1 mt-1">
                    {zone.icon}
                    <span className="text-[9px] text-slate-500 font-semibold">{zone.text}</span>
                  </div>
                </div>

                {/* Matches Played */}
                <div className="col-span-1.5 text-center text-xs font-semibold text-slate-400 font-mono">
                  {couple.played || 0}
                </div>

                {/* Win / Loss Record */}
                <div className="col-span-1.5 text-center flex flex-col">
                  <span className="text-xs font-bold text-emerald-400 font-mono">{couple.won || 0}</span>
                  <span className="text-[9px] text-slate-600 font-mono">{couple.lost || 0}d</span>
                </div>

                {/* Ranking Points */}
                <div className="col-span-2 text-right flex flex-col pr-1">
                  <span className={`text-sm font-extrabold font-mono ${isCurrentUser ? 'text-[#BEF264]' : 'text-white'}`}>
                    {couple.points || 0}
                  </span>
                  <span className="text-[8px] text-slate-500 font-mono uppercase tracking-wider">
                    {couple.setsWon - couple.setsLost >= 0 ? '+' : ''}{couple.setsWon - couple.setsLost} sets
                  </span>
                </div>

              </motion.div>
            );
          })}

        </div>
      )}

      {/* Tabla General de todos los Integrantes */}
      <div id="global_ranking_section" className="space-y-3 bg-[#1E293B]/30 border border-slate-700/30 p-4 rounded-3xl mt-6">
        <div className="flex flex-col gap-1 px-1">
          <h3 className="text-xs font-bold text-[#BEF264] flex items-center gap-2 uppercase tracking-wider">
            <Trophy className="w-4.5 h-4.5 text-[#BEF264]" />
            Clasificación General (Todas las Parejas)
          </h3>
          <p className="text-[10px] text-slate-400">Posiciones unificadas del 1º al último combinando todas las divisiones</p>
        </div>

        <div className="space-y-2">
          {/* Table Header Row */}
          <div className="grid grid-cols-12 px-4 py-2 text-[10px] font-bold text-slate-500 uppercase tracking-widest bg-[#1E293B]/20 rounded-lg">
            <div className="col-span-1.5 text-center">Pos</div>
            <div className="col-span-4 pl-2">Pareja</div>
            <div className="col-span-2.5 text-center">División</div>
            <div className="col-span-1 text-center">PJ</div>
            <div className="col-span-1.5 text-center">W/L</div>
            <div className="col-span-1.5 text-right">Pts</div>
          </div>

          {/* List Rows */}
          {filteredGlobalCouples.length === 0 ? (
            <div className="text-center text-xs text-slate-500 py-6">
              No hay parejas registradas o coincidentes con la búsqueda.
            </div>
          ) : (
            filteredGlobalCouples.map((couple, index) => {
              // Find real overall rank (based on index in complete global list)
              const realRank = searchQuery.trim() === ''
                ? index + 1
                : globalSortedCouples.findIndex(c => c.id === couple.id) + 1;

              const isCurrentUser = couple.player1.id === currentPlayer.id || couple.player2.id === currentPlayer.id;

              // Division badge style
              const getDivisionBadge = (division: string) => {
                if (division === 'División 1') {
                  return (
                    <span className="px-2 py-0.5 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 text-[9px] font-bold rounded-full inline-block">
                      Div 1
                    </span>
                  );
                } else if (division === 'División 2') {
                  return (
                    <span className="px-2 py-0.5 bg-sky-500/10 text-sky-400 border border-sky-500/20 text-[9px] font-bold rounded-full inline-block">
                      Div 2
                    </span>
                  );
                } else {
                  return (
                    <span className="px-2 py-0.5 bg-amber-500/10 text-amber-400 border border-amber-500/20 text-[9px] font-bold rounded-full inline-block">
                      Div 3
                    </span>
                  );
                }
              };

              return (
                <motion.div
                  key={`global_${couple.id}`}
                  initial={{ opacity: 0, y: 5 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: Math.min(index * 0.02, 0.3) }}
                  id={`global_ranking_row_${couple.id}`}
                  className={`grid grid-cols-12 items-center p-3 rounded-2xl transition-all border border-slate-700/30 bg-[#1E293B] ${
                    isCurrentUser ? 'ring-1 ring-[#BEF264] bg-[#BEF264]/5' : ''
                  }`}
                >
                  {/* Pos */}
                  <div className="col-span-1.5 flex items-center justify-center">
                    <span className="text-[#BEF264] font-mono font-bold text-xs">{realRank}º</span>
                  </div>

                  {/* Player Detail */}
                  <div className="col-span-4 pl-2 flex flex-col justify-center min-w-0">
                    <div className="flex items-start gap-1.5 min-w-0">
                      <div className="flex flex-col min-w-0">
                        <span className={`text-xs font-bold truncate ${isCurrentUser ? 'text-[#BEF264]' : 'text-slate-100'}`}>
                          {couple.player1.name}
                        </span>
                        {couple.id.endsWith('_single') ? (
                          <span className="text-[10px] text-slate-500 italic">
                            (Sin pareja)
                          </span>
                        ) : (
                          <span className={`text-xs font-semibold truncate ${isCurrentUser ? 'text-[#BEF264]/80' : 'text-slate-400'}`}>
                            {couple.player2.name}
                          </span>
                        )}
                      </div>
                      {isCurrentUser && (
                        <span className="px-1.5 py-0.5 bg-[#BEF264]/10 border border-[#BEF264]/30 text-[#BEF264] text-[8px] font-extrabold uppercase rounded shrink-0 font-sans mt-0.5">
                          Tú
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Division Badge */}
                  <div className="col-span-2.5 text-center">
                    {getDivisionBadge(couple.division)}
                  </div>

                  {/* Matches Played */}
                  <div className="col-span-1 text-center text-xs font-semibold text-slate-400 font-mono">
                    {couple.played || 0}
                  </div>

                  {/* Win / Loss Record */}
                  <div className="col-span-1.5 text-center flex flex-col">
                    <span className="text-xs font-bold text-emerald-400 font-mono">{couple.won || 0}</span>
                    <span className="text-[9px] text-slate-600 font-mono">{couple.lost || 0}d</span>
                  </div>

                  {/* Ranking Points */}
                  <div className="col-span-1.5 text-right flex flex-col pr-1">
                    <span className={`text-sm font-extrabold font-mono ${isCurrentUser ? 'text-[#BEF264]' : 'text-white'}`}>
                      {couple.points || 0}
                    </span>
                    <span className="text-[8px] text-slate-500 font-mono uppercase tracking-wider">
                      {couple.setsWon - couple.setsLost >= 0 ? '+' : ''}{couple.setsWon - couple.setsLost} sets
                    </span>
                  </div>
                </motion.div>
              );
            })
          )}
        </div>
      </div>

      {/* Explanatory Legend footer */}
      <div className="bg-[#1E293B]/50 p-4 border border-slate-700/30 rounded-3xl space-y-3">
        <span className="text-xs font-bold text-white uppercase tracking-wider block">Leyenda de la Clasificación</span>
        <div className="grid grid-cols-2 gap-3">
          <div className="flex items-start gap-2">
            <span className="w-1.5 h-6 bg-[#BEF264] rounded shrink-0"></span>
            <div>
              <span className="text-[10px] font-bold text-slate-300 block leading-none">Ascenso</span>
              <p className="text-[9px] text-slate-500 mt-1 leading-normal">La mejor pareja de la división sube de grupo para la próxima ronda.</p>
            </div>
          </div>
          <div className="flex items-start gap-2">
            <span className="w-1.5 h-6 bg-rose-500 rounded shrink-0"></span>
            <div>
              <span className="text-[10px] font-bold text-slate-300 block leading-none">Descenso</span>
              <p className="text-[9px] text-slate-500 mt-1 leading-normal">La peor pareja de la división baja de grupo para la próxima ronda.</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
