import React from 'react';
import { BookOpen, Trophy, ShieldAlert, Award, Calendar, RefreshCw } from 'lucide-react';
import { motion } from 'motion/react';

export default function RulesView() {
  const rules = [
    {
      title: "1. Sistema de Divisiones (Grupos)",
      icon: <Trophy className="w-5 h-5 text-[#BEF264]" />,
      content: "La liga está organizada en 3 grupos: División 1 (Élite), División 2 (Intermedio) y División 3 (Iniciación). Los nuevos integrantes de la aplicación inician automáticamente en la División 3, desde donde deberán ganarse su ascenso puntuando en las jornadas."
    },
    {
      title: "2. Registro y Reparto de Puntos",
      icon: <Award className="w-5 h-5 text-[#BEF264]" />,
      content: "Cada partido se juega a un máximo de 3 sets (al mejor de 2 sets con un tercer set de desempate en caso de tablas 1-1). La puntuación se calcula de forma automática y personalizada:",
      list: [
        "Participación: +1 punto para todos los integrantes que jueguen el partido.",
        "Set Ganado: +1 punto por cada set individual que gane tu equipo.",
        "Victoria: +3 puntos extra para cada jugador del equipo ganador.",
        "Resultado 2-0: Ganadores (+6 pts) / Perdedores (+1 pt)",
        "Resultado 2-1: Ganadores (+6 pts) / Perdedores (+2 pts)"
      ]
    },
    {
      title: "3. Ascensos y Descensos Automáticos",
      icon: <RefreshCw className="w-5 h-5 text-[#BEF264]" />,
      content: "Cada jornada tiene una duración predeterminada (por ejemplo, semanal o quincenal). Al concluir el plazo de tiempo:",
      list: [
        "División 1: Los 2 últimos de la tabla descienden a División 2.",
        "División 2: Los 2 primeros ascienden a División 1. Los 2 últimos descienden a División 3.",
        "División 3: Los 2 primeros ascienden a División 2.",
        "Reinicio de Puntos: Tras reorganizar las divisiones, se inicia una nueva jornada y los casilleros de puntos se resetean a cero."
      ]
    },
    {
      title: "4. Criterios de Desempate en Clasificación",
      icon: <ShieldAlert className="w-5 h-5 text-[#BEF264]" />,
      content: "En caso de que dos o más jugadores terminen empatados en puntos acumulados al final de una Jornada, el sistema de clasificación calcula el orden según los siguientes criterios secuenciales:",
      list: [
        "1º Criterio: Mayor número de partidos ganados (Victorias).",
        "2º Criterio: Mayor diferencia de sets ganados vs sets perdidos.",
        "3º Criterio: Mayor diferencia de juegos ganados vs juegos perdidos.",
        "4º Criterio: Orden cronológico de registro de perfil en la aplicación."
      ]
    }
  ];

  return (
    <div id="rules_view_container" className="space-y-6 pb-24 text-white p-4">
      {/* Header */}
      <div className="flex flex-col gap-1">
        <h2 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-[#BEF264]" />
          Reglamento y Normativa
        </h2>
        <p className="text-xs text-slate-400">Normas de juego, cálculo de puntos y sistema de ascensos</p>
      </div>

      {/* Rules Loop */}
      <div className="space-y-4">
        {rules.map((rule, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="bg-[#1E293B] border border-slate-700/50 rounded-3xl p-5 shadow-md space-y-3"
          >
            <div className="flex items-center gap-3 border-b border-slate-700/30 pb-3">
              <div className="p-1.5 bg-[#BEF264]/10 border border-[#BEF264]/20 rounded-xl text-[#BEF264]">
                {rule.icon}
              </div>
              <h3 className="font-bold text-sm text-white">{rule.title}</h3>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              {rule.content}
            </p>

            {rule.list && (
              <ul className="text-xs text-slate-300 space-y-1.5 pl-1.5 list-none">
                {rule.list.map((item, i) => (
                  <li key={i} className="flex items-start gap-1.5">
                    <span className="text-[#BEF264] font-bold shrink-0">•</span>
                    <span className="leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            )}
          </motion.div>
        ))}
      </div>

      {/* Placeholder Custom Rules Section */}
      <div className="bg-[#BEF264]/5 border border-dashed border-[#BEF264]/20 p-5 rounded-3xl space-y-2">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-[#BEF264]" />
          <h4 className="text-xs font-bold text-[#BEF264] uppercase tracking-wider">Próxima sección de normas personalizadas</h4>
        </div>
        <p className="text-xs text-slate-400 leading-relaxed">
          Este apartado está configurado para albergar las normas específicas que desees incorporar más adelante (normas de reserva de pistas, penalizaciones por inasistencia, políticas de bolas de juego, etc.). Envíaselas al administrador o agrégalas cuando lo consideres oportuno.
        </p>
      </div>
    </div>
  );
}
