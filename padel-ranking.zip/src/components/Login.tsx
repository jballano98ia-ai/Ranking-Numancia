import React, { useState, useEffect } from 'react';
import { auth, db } from '../lib/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, getDoc } from 'firebase/firestore';
import { registerPlayerProfile, getPlayerByEmail, getPlayers, updatePlayerPartner } from '../lib/db';
import { Player } from '../types';
import { Trophy, Activity, Mail, Lock, User, KeyRound, AlertCircle, Users } from 'lucide-react';
import { motion } from 'motion/react';

interface LoginProps {
  onLoginSuccess: (player: Player) => void;
}

export default function Login({ onLoginSuccess }: LoginProps) {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [allPlayers, setAllPlayers] = useState<Player[]>([]);
  const [selectedPartnerId, setSelectedPartnerId] = useState<string>('');

  useEffect(() => {
    async function loadPlayers() {
      try {
        const list = await getPlayers();
        setAllPlayers(list.filter(p => p.role !== 'admin'));
      } catch (err) {
        console.error('Error fetching players:', err);
      }
    }
    loadPlayers();
  }, []);

  // List of seeded accounts for quick simulation
  const testAccounts = [
    { id: 'p_galan', name: 'Alejandro Galán', email: 'galan@padel.com', division: 'División 1', role: 'player' },
    { id: 'p_bela', name: 'Fernando Belasteguín', email: 'bela@padel.com', division: 'División 2', role: 'player' },
    { id: 'p_yanguas', name: 'Mike Yanguas', email: 'yanguas@padel.com', division: 'División 3', role: 'player' },
    { id: 'p_admin', name: 'Club Admin', email: 'admin@padel.com', division: 'División 1', role: 'admin' },
  ];

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignUp) {
        if (!fullName.trim()) {
          throw new Error('Por favor, introduce tu nombre completo.');
        }
        
        try {
          // Attempt standard Firebase Auth
          const userCredential = await createUserWithEmailAndPassword(auth, email, password);
          const user = userCredential.user;
          const profile = await registerPlayerProfile(user.uid, fullName, email, 'player');
          
          if (selectedPartnerId) {
            await updatePlayerPartner(profile.id, selectedPartnerId);
            const updatedSnap = await getDoc(doc(db, 'players', profile.id));
            if (updatedSnap.exists()) {
              onLoginSuccess(updatedSnap.data() as Player);
              return;
            }
          }
          
          onLoginSuccess(profile);
        } catch (authErr: any) {
          // If Auth is disabled or fails due to environment constraints, fall back to Firestore Simulation
          if (
            authErr.code === 'auth/operation-not-allowed' || 
            authErr.code === 'auth/unauthorized-domain' || 
            authErr.message?.includes('operation-not-allowed') || 
            authErr.message?.includes('auth/operation-not-allowed')
          ) {
            console.warn('Firebase Auth is disabled or restricted. Falling back to Firestore-backed simulation.');
            
            // Check if email already exists in Firestore
            const existingPlayer = await getPlayerByEmail(email);
            if (existingPlayer) {
              throw new Error('Este correo electrónico ya está registrado.');
            }
            
            // Create a cloud-persistent simulated player document starting with 'p_' prefix
            const simId = `p_u_${Math.random().toString(36).substr(2, 9)}`;
            const profile = await registerPlayerProfile(simId, fullName, email, 'player');
            
            if (selectedPartnerId) {
              await updatePlayerPartner(simId, selectedPartnerId);
              const updatedSnap = await getDoc(doc(db, 'players', simId));
              if (updatedSnap.exists()) {
                onLoginSuccess(updatedSnap.data() as Player);
                return;
              }
            }
            
            onLoginSuccess(profile);
          } else {
            throw authErr;
          }
        }
      } else {
        try {
          // Attempt standard Firebase Auth
          const userCredential = await signInWithEmailAndPassword(auth, email, password);
          const user = userCredential.user;
          const playerRef = doc(db, 'players', user.uid);
          const playerSnap = await getDoc(playerRef);

          if (playerSnap.exists()) {
            onLoginSuccess(playerSnap.data() as Player);
          } else {
            const profile = await registerPlayerProfile(user.uid, user.displayName || 'Jugador Nuevo', email, 'player');
            onLoginSuccess(profile);
          }
        } catch (authErr: any) {
          // If Auth is disabled or fails due to configuration/user issues, fall back to Firestore simulation lookup
          if (
            authErr.code === 'auth/operation-not-allowed' || 
            authErr.code === 'auth/unauthorized-domain' || 
            authErr.message?.includes('operation-not-allowed') || 
            authErr.message?.includes('auth/operation-not-allowed') ||
            authErr.code === 'auth/user-not-found' || 
            authErr.code === 'auth/wrong-password'
          ) {
            console.warn('Authentication fallback. Searching player directly in Firestore...');
            
            // Search in Firestore
            const existingPlayer = await getPlayerByEmail(email);
            if (existingPlayer) {
              onLoginSuccess(existingPlayer);
            } else {
              // Also check if they are trying to log in as one of the pre-seeded players using email
              const seedMatch = testAccounts.find(acc => acc.email.toLowerCase() === email.toLowerCase().trim());
              if (seedMatch) {
                // Fetch or register the pre-seeded player
                const profile = await registerPlayerProfile(seedMatch.id, seedMatch.name, seedMatch.email, seedMatch.role as 'admin' | 'player');
                profile.division = seedMatch.division;
                onLoginSuccess(profile);
              } else {
                throw new Error('No se ha encontrado ninguna cuenta con ese correo electrónico. Regístrate para crear una.');
              }
            }
          } else {
            throw authErr;
          }
        }
      }
    } catch (err: any) {
      console.error(err);
      let errMsg = 'Ocurrió un error en el inicio de sesión.';
      if (err.code === 'auth/email-already-in-use') errMsg = 'Este correo electrónico ya está registrado.';
      else if (err.code === 'auth/wrong-password') errMsg = 'Contraseña incorrecta.';
      else if (err.code === 'auth/user-not-found') errMsg = 'No se encontró ningún usuario con este correo.';
      else if (err.message) errMsg = err.message;
      setError(errMsg);
    } finally {
      setLoading(false);
    }
  };

  // Quick switch simulator
  const handleQuickLogin = async (account: typeof testAccounts[0]) => {
    setLoading(true);
    setError('');
    try {
      const playerRef = doc(db, 'players', account.id);
      const playerSnap = await getDoc(playerRef);
      if (playerSnap.exists()) {
        onLoginSuccess(playerSnap.data() as Player);
      } else {
        // If not found, register it
        const profile = await registerPlayerProfile(account.id, account.name, account.email, account.role as 'admin' | 'player');
        // Override division if needed
        profile.division = account.division;
        onLoginSuccess(profile);
      }
    } catch (err) {
      console.error(err);
      setError('Error al iniciar sesión de simulación.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="login_container" className="flex flex-col items-center justify-center min-h-[90vh] p-4 text-white">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-[#1E293B] border border-slate-700/50 rounded-3xl p-6 shadow-2xl space-y-6"
      >
        {/* App Title & Logo */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-[#BEF264]/10 border border-[#BEF264]/20 text-[#BEF264] mb-2">
            <Trophy className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white font-sans">
            PÁDEL <span className="text-[#BEF264]">RANKING</span>
          </h1>
          <p className="text-sm text-slate-400">
            Control de ranking y ligas de grupos en tiempo real
          </p>
        </div>

        {/* Error Alert */}
        {error && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex items-start gap-2 bg-rose-500/10 border border-rose-500/30 text-rose-300 p-3 rounded-lg text-xs"
          >
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{error}</span>
          </motion.div>
        )}

        {/* Regular Login Form */}
        <form onSubmit={handleAuth} className="space-y-4">
          {isSignUp && (
            <div className="space-y-3">
              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300" htmlFor="name_input">Nombre Completo</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                    <User className="w-4 h-4" />
                  </span>
                  <input
                    id="name_input"
                    type="text"
                    placeholder="Ej. Alejandro Galán"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 bg-[#0F172A] border border-slate-700/50 rounded-xl text-sm focus:outline-none focus:border-[#BEF264] text-white transition-colors"
                    required={isSignUp}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-xs font-semibold text-slate-300 animate-pulse flex items-center gap-1.5" htmlFor="partner_signup_select">
                  <Users className="w-3.5 h-3.5 text-[#BEF264]" />
                  Selecciona tu Pareja (Opcional)
                </label>
                <div className="relative">
                  <select
                    id="partner_signup_select"
                    value={selectedPartnerId}
                    onChange={(e) => setSelectedPartnerId(e.target.value)}
                    className="w-full px-3 py-2.5 bg-[#0F172A] border border-slate-700/50 rounded-xl text-xs focus:outline-none focus:border-[#BEF264] text-white transition-colors appearance-none cursor-pointer"
                  >
                    <option value="" className="bg-[#1E293B]">-- Elegir más tarde / Jugar solo --</option>
                    {allPlayers.map(p => (
                      <option key={p.id} value={p.id} className="bg-[#1E293B]">
                        {p.name} ({p.division})
                      </option>
                    ))}
                  </select>
                  <span className="absolute inset-y-0 right-3 flex items-center pointer-events-none text-slate-500 text-xs">▼</span>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300" htmlFor="email_input">Correo Electrónico</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Mail className="w-4 h-4" />
              </span>
              <input
                id="email_input"
                type="email"
                placeholder="usuario@padel.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-[#0F172A] border border-slate-700/50 rounded-xl text-sm focus:outline-none focus:border-[#BEF264] text-white transition-colors"
                required
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-slate-300" htmlFor="password_input">Contraseña</label>
            <div className="relative">
              <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-500">
                <Lock className="w-4 h-4" />
              </span>
              <input
                id="password_input"
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-9 pr-3 py-2.5 bg-[#0F172A] border border-slate-700/50 rounded-xl text-sm focus:outline-none focus:border-[#BEF264] text-white transition-colors"
                required
              />
            </div>
          </div>

          <button
            id="auth_submit_btn"
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-[#BEF264] hover:opacity-90 disabled:bg-[#1E293B] disabled:text-slate-500 text-slate-900 font-bold rounded-xl text-sm transition-colors cursor-pointer flex items-center justify-center gap-2 mt-2"
          >
            {loading ? (
              <span className="inline-block animate-spin rounded-full h-4 w-4 border-2 border-slate-950 border-t-transparent"></span>
            ) : isSignUp ? (
              'Crear Cuenta'
            ) : (
              'Entrar'
            )}
          </button>
        </form>

        {/* Toggle Sign Up / Sign In */}
        <div className="text-center">
          <button
            id="toggle_signup_btn"
            onClick={() => setIsSignUp(!isSignUp)}
            className="text-xs text-slate-400 hover:text-[#BEF264] transition-colors"
          >
            {isSignUp ? '¿Ya tienes cuenta? Inicia sesión' : '¿No tienes cuenta? Regístrate aquí'}
          </button>
        </div>

        {/* Separator */}
        <div className="relative my-4 flex py-2 items-center">
          <div className="flex-grow border-t border-slate-700/50"></div>
          <span className="flex-shrink mx-3 text-slate-400 text-xs font-mono uppercase tracking-widest">Simulación rápida</span>
          <div className="flex-grow border-t border-slate-700/50"></div>
        </div>

        {/* Quick Simulator Accounts */}
        <div className="space-y-2">
          <p className="text-xs text-center text-slate-400 flex items-center justify-center gap-1">
            <KeyRound className="w-3 h-3 text-[#BEF264]" />
            Accede al instante como jugador de prueba:
          </p>
          <div className="grid grid-cols-2 gap-2">
            {testAccounts.map((account) => (
              <button
                key={account.id}
                id={`quick_login_${account.id}`}
                onClick={() => handleQuickLogin(account)}
                disabled={loading}
                className="p-2 bg-[#0F172A] hover:bg-[#0F172A]/80 border border-slate-700/50 rounded-xl text-left transition-all hover:scale-[1.02] active:scale-[0.98] group"
              >
                <div className="text-xs font-medium text-white group-hover:text-[#BEF264] truncate">
                  {account.name}
                </div>
                <div className="text-[10px] text-slate-500 font-mono truncate flex items-center justify-between mt-0.5">
                  <span>{account.division}</span>
                  {account.role === 'admin' && (
                    <span className="px-1 py-0.2 bg-[#BEF264]/10 text-[#BEF264] rounded text-[8px] font-sans">
                      Admin
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
